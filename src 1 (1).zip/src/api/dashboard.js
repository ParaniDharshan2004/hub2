import dayjs from 'dayjs';
import { getDb } from './db';
import { delay, paymentModes, serviceAreas } from './masters';
import { areaWorkloadToday } from './visits';

export async function getDashboardSummary({ date = dayjs().format('YYYY-MM-DD') } = {}) {
  await delay(300);
  const db = getDb();

  const todayVisits = db.visits.filter((v) => dayjs(v.date).format('YYYY-MM-DD') === date);
  const completedToday = todayVisits.filter((v) => v.status === 'Completed');
  const pendingToday = todayVisits.filter((v) => v.status === 'Scheduled');
  const rescheduledToday = todayVisits.filter((v) => (v.rescheduleHistory || []).some((h) => dayjs(h.changedOn).format('YYYY-MM-DD') === date));

  const activeSubscriptions = db.subscriptions.filter((s) => s.status === 'Active');
  const periodsWithSub = db.periods
    .filter((p) => p.status === 'Active')
    .map((p) => ({ period: p, subscription: db.subscriptions.find((s) => s.id === p.subscriptionId) }));

  const dueSoon = periodsWithSub.filter(({ period }) => {
    const daysLeft = dayjs(period.endDate).diff(dayjs(), 'day');
    return daysLeft >= 0 && daysLeft <= 7;
  });
  const overdue = periodsWithSub.filter(({ period }) => dayjs(period.endDate).isBefore(dayjs(), 'day'));

  const todaysPayments = db.payments.filter((p) => dayjs(p.paymentDate).format('YYYY-MM-DD') === date && p.status !== 'Reversed');
  const monthStart = dayjs().startOf('month');
  const mtdPayments = db.payments.filter((p) => dayjs(p.paymentDate).isAfter(monthStart) && p.status !== 'Reversed');

  const collectionByMode = paymentModes.map((m) => ({
    mode: m,
    total: todaysPayments.filter((p) => p.modeId === m.id).reduce((s, p) => s + p.amount, 0),
  }));

  const recentBookings = [...db.bookings]
    .filter((b) => b.status === 'Confirmed')
    .sort((a, b) => new Date(b.confirmedOn) - new Date(a.confirmedOn))
    .slice(0, 5)
    .map((b) => ({
      ...b,
      customer: db.customers.find((c) => c.id === b.customerId),
    }));

  const upcomingVisits = db.visits
    .filter((v) => v.status === 'Scheduled' && dayjs(v.date).isAfter(dayjs().subtract(1, 'day')))
    .sort((a, b) => new Date(a.date) - new Date(b.date))
    .slice(0, 6)
    .map((v) => {
      const subscription = db.subscriptions.find((s) => s.id === v.subscriptionId);
      const customer = subscription ? db.customers.find((c) => c.id === subscription.customerId) : null;
      return { ...v, customer };
    });

  const staleDrafts = db.bookings.filter(
    (b) => b.status === 'Draft' && dayjs().diff(dayjs(b.createdOn), 'day') >= 2
  );

  return {
    date,
    kpis: {
      todayVisits: todayVisits.length,
      completedToday: completedToday.length,
      pendingToday: pendingToday.length,
      rescheduledToday: rescheduledToday.length,
      activeSubscriptions: activeSubscriptions.length,
      renewalsDueSoon: dueSoon.length,
      renewalsDue: overdue.length,
      todaysCollection: todaysPayments.reduce((s, p) => s + p.amount, 0),
      mtdCollection: mtdPayments.reduce((s, p) => s + p.amount, 0),
    },
    areaWorkload: areaWorkloadToday(todayVisits.map((v) => ({ ...v }))),
    collectionByMode,
    recentBookings,
    upcomingVisits,
    exceptions: {
      staleDrafts,
    },
    serviceAreas,
  };
}
