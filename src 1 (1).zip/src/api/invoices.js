import { getDb, saveDb, recordAudit } from './db';
import { delay } from './masters';

function toInvoiceRow(invoice) {
  const db = getDb();
  const booking = db.bookings.find((b) => b.id === invoice.bookingId);
  const customer = db.customers.find((c) => c.id === invoice.customerId);
  const payment = db.payments.find((p) => p.id === invoice.paymentId);
  const address = booking ? db.addresses.find((a) => a.id === booking.addressId) : null;
  return { ...invoice, booking, customer, payment, address };
}

export async function listInvoices({ search = '' } = {}) {
  await delay();
  const db = getDb();
  let rows = db.invoices.map(toInvoiceRow);

  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (i) =>
        i.invoiceNumber.toLowerCase().includes(q) ||
        i.customer?.name.toLowerCase().includes(q) ||
        i.customer?.customerNumber.toLowerCase().includes(q) ||
        i.booking?.bookingNumber.toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.date) - new Date(a.date));
}

export async function getInvoice(invoiceNumber) {
  await delay(250);
  const db = getDb();
  const invoice = db.invoices.find((i) => i.invoiceNumber === invoiceNumber);
  if (!invoice) return null;
  return toInvoiceRow(invoice);
}

export async function recordInvoiceDownload(invoiceNumber) {
  await delay(150);
  recordAudit({ module: 'Invoices', action: 'DOWNLOAD', entityType: 'Invoice', entityNumber: invoiceNumber });
  saveDb();
}
