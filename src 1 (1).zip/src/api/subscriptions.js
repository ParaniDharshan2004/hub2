import dayjs from 'dayjs';
import { getDb, saveDb, recordAudit } from './db';
import { generateId } from '../utils/idGenerator';
import { delay, plans, frequencies } from './masters';
import { quotePricing } from './bookings';

function toSubscriptionRow(sub) {
  const db = getDb();
  const customer = db.customers.find((c) => c.id === sub.customerId);
  const address = db.addresses.find((a) => a.id === sub.addressId);
  const periods = db.periods
    .filter((p) => p.subscriptionId === sub.id)
    .sort((a, b) => new Date(b.startDate) - new Date(a.startDate));
  const currentPeriod = periods[0] || null;
  const visits = currentPeriod ? db.visits.filter((v) => v.periodId === currentPeriod.id) : [];
  const nextVisit = visits
    .filter((v) => v.status === 'Scheduled')
    .sort((a, b) => new Date(a.date) - new Date(b.date))[0];

  const renewalStatus = currentPeriod
    ? dayjs(currentPeriod.endDate).diff(dayjs(), 'day') <= 7
      ? 'Renewal Due Soon'
      : dayjs(currentPeriod.endDate).isBefore(dayjs())
      ? 'Renewal Overdue'
      : 'On Track'
    : 'No Period';

  return { ...sub, customer, address, periods, currentPeriod, nextVisit, renewalStatus };
}

export async function listSubscriptions({ search = '', status = 'All' } = {}) {
  await delay();
  const db = getDb();
  let rows = db.subscriptions.map(toSubscriptionRow);

  if (status !== 'All') rows = rows.filter((s) => s.status === status);
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (s) =>
        s.subscriptionNumber.toLowerCase().includes(q) ||
        s.customer?.name.toLowerCase().includes(q) ||
        s.customer?.customerNumber.toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn));
}

export async function getSubscription(subscriptionNumber) {
  await delay(300);
  const db = getDb();
  const sub = db.subscriptions.find((s) => s.subscriptionNumber === subscriptionNumber);
  if (!sub) return null;
  const row = toSubscriptionRow(sub);
  const periodsWithVisits = row.periods.map((p) => ({
    ...p,
    visits: db.visits.filter((v) => v.periodId === p.id).sort((a, b) => a.sequence - b.sequence),
    booking: db.bookings.find((b) => b.id === p.bookingId),
  }));
  return { ...row, periods: periodsWithVisits };
}

// Renewal: purchases a new period on the *same* subscription account.
// Prior periods, their visits, and every historical booking/payment/invoice
// are left completely untouched.
export async function renewSubscription(subscriptionNumber, { planId, frequencyId, startDate, paymentModeId }) {
  await delay(500);
  const db = getDb();
  const sub = db.subscriptions.find((s) => s.subscriptionNumber === subscriptionNumber);
  if (!sub) throw new Error('Subscription not found');

  const address = db.addresses.find((a) => a.id === sub.addressId);
  const priorPeriods = db.periods.filter((p) => p.subscriptionId === sub.id);
  const lastPeriod = priorPeriods.sort((a, b) => new Date(b.startDate) - new Date(a.startDate))[0];
  const bathrooms = lastPeriod
    ? db.bookings.find((b) => b.id === lastPeriod.bookingId)?.bathrooms
    : 1;

  const quote = quotePricing({ planId, frequencyId, bathrooms: bathrooms || 1, discount: 0 });
  if (!quote) throw new Error('Unable to price this renewal.');

  const now = new Date();

  // Renewal booking (a new, independent commercial record).
  const booking = {
    id: `int-bkg-${db.bookings.length + 1}-${Date.now()}`,
    bookingNumber: generateId.booking(now),
    type: 'Renewal',
    customerId: sub.customerId,
    addressId: sub.addressId,
    offeringId: sub.offeringId,
    bathrooms: bathrooms || 1,
    frequencyId,
    planId,
    pricePerService: quote.pricePerService,
    numServices: quote.numServices,
    serviceCharges: quote.serviceCharges,
    discount: 0,
    discountReason: null,
    taxableAmount: quote.taxableAmount,
    taxes: quote.taxes,
    total: quote.total,
    startDate,
    slotId: lastPeriod ? db.visits.find((v) => v.periodId === lastPeriod.id)?.slotId : null,
    status: 'Confirmed',
    createdOn: now.toISOString(),
    confirmedOn: now.toISOString(),
    subscriptionId: sub.id,
  };
  db.bookings.push(booking);

  const payment = {
    id: `int-pay-${db.payments.length + 1}-${Date.now()}`,
    paymentNumber: generateId.payment(now),
    bookingId: booking.id,
    customerId: sub.customerId,
    amount: booking.total,
    modeId: paymentModeId,
    reference: null,
    paymentDate: now.toISOString(),
    status: 'Recorded',
  };
  db.payments.push(payment);

  const invoice = {
    id: `int-inv-${db.invoices.length + 1}-${Date.now()}`,
    invoiceNumber: generateId.invoice(now),
    bookingId: booking.id,
    customerId: sub.customerId,
    paymentId: payment.id,
    amount: booking.total,
    taxableAmount: booking.taxableAmount,
    taxes: booking.taxes,
    date: now.toISOString(),
  };
  db.invoices.push(invoice);

  const plan = plans.find((p) => p.id === planId);
  const start = dayjs(startDate);
  const end = start.add(plan.termMonths, 'month').subtract(1, 'day');
  const period = {
    id: `int-per-${db.periods.length + 1}-${Date.now()}`,
    periodNumber: generateId.period(),
    subscriptionId: sub.id,
    bookingId: booking.id,
    planId,
    frequencyId,
    totalServices: quote.numServices,
    completedServices: 0,
    remainingServices: quote.numServices,
    startDate: start.toISOString(),
    endDate: end.toISOString(),
    status: 'Active',
    kind: 'Renewal',
  };
  db.periods.push(period);

  if (lastPeriod) lastPeriod.status = 'Expired';

  const frequency = frequencies.find((f) => f.id === frequencyId);
  const intervalDays = Math.max(1, Math.round(28 / frequency.visitsPerMonth));
  for (let i = 0; i < quote.numServices; i += 1) {
    const visitDate = start.add(i * intervalDays, 'day');
    db.visits.push({
      id: `int-visit-${db.visits.length + 1}-${Date.now()}-${i}`,
      visitNumber: generateId.visit(visitDate.toDate()),
      periodId: period.id,
      subscriptionId: sub.id,
      sequence: i + 1,
      date: visitDate.toISOString(),
      slotId: booking.slotId,
      areaId: address?.area,
      status: 'Scheduled',
    });
  }

  sub.status = 'Active';

  recordAudit({
    module: 'Subscriptions',
    action: 'RENEW',
    entityType: 'Subscription',
    entityNumber: sub.subscriptionNumber,
    details: `New period ${period.periodNumber} via booking ${booking.bookingNumber}`,
  });

  saveDb();
  return { subscription: toSubscriptionRow(sub), booking, payment, invoice, period };
}
