import dayjs from 'dayjs';
import { getDb, saveDb, recordAudit, recordStatusChange } from './db';
import { delay, serviceAreas } from './masters';

function toVisitRow(visit) {
  const db = getDb();
  const period = db.periods.find((p) => p.id === visit.periodId);
  const subscription = db.subscriptions.find((s) => s.id === visit.subscriptionId);
  const booking = period ? db.bookings.find((b) => b.id === period.bookingId) : null;
  const customer = subscription ? db.customers.find((c) => c.id === subscription.customerId) : null;
  const addressId = subscription?.addressId || booking?.addressId;
  const address = db.addresses.find((a) => a.id === addressId);

  return { ...visit, period, subscription, booking, customer, address };
}

export function areaWorkloadToday(visits) {
  return serviceAreas
    .map((area) => ({
      area,
      total: visits.filter((visit) => visit.areaId === area.id).length,
      completed: visits.filter((visit) => visit.areaId === area.id && visit.status === 'Completed').length,
    }))
    .filter((row) => row.total > 0);
}

export async function listVisits({ search = '', status = 'All', area = 'All', date, dateFrom, dateTo } = {}) {
  await delay();
  let rows = getDb().visits.map(toVisitRow);

  if (status !== 'All') rows = rows.filter((visit) => visit.status === status);
  if (area !== 'All') rows = rows.filter((visit) => visit.areaId === area);
  if (date) rows = rows.filter((visit) => dayjs(visit.date).format('YYYY-MM-DD') === date);
  if (dateFrom) rows = rows.filter((visit) => dayjs(visit.date).isSameOrAfter?.(dayjs(dateFrom)) ?? visit.date >= dateFrom);
  if (dateTo) rows = rows.filter((visit) => dayjs(visit.date).isSameOrBefore?.(dayjs(dateTo).endOf('day')) ?? visit.date <= dateTo);

  if (search.trim()) {
    const query = search.trim().toLowerCase();
    rows = rows.filter(
      (visit) =>
        visit.visitNumber.toLowerCase().includes(query) ||
        visit.customer?.name.toLowerCase().includes(query) ||
        visit.customer?.customerNumber.toLowerCase().includes(query)
    );
  }

  return rows.sort((a, b) => new Date(a.date) - new Date(b.date));
}

export async function getVisit(visitNumber) {
  await delay(250);
  const visit = getDb().visits.find((item) => item.visitNumber === visitNumber);
  return visit ? toVisitRow(visit) : null;
}

export async function completeVisit(visitNumber, { completedOn, completedBy = 'Demo Admin', remarks = '' } = {}) {
  await delay(350);
  const db = getDb();
  const visit = db.visits.find((item) => item.visitNumber === visitNumber);
  if (!visit) throw new Error('Visit not found.');
  if (visit.status === 'Completed') throw new Error('This visit has already been completed.');
  if (visit.status === 'Cancelled') throw new Error('Cancelled visits cannot be completed.');

  const previousStatus = visit.status;
  visit.status = 'Completed';
  visit.completedOn = completedOn || new Date().toISOString();
  visit.completedBy = completedBy;
  visit.completionRemarks = remarks || '';

  const period = db.periods.find((item) => item.id === visit.periodId);
  if (period) {
    period.completedServices = Math.min(period.totalServices, (period.completedServices || 0) + 1);
    period.remainingServices = Math.max(0, period.totalServices - period.completedServices);
  }

  recordStatusChange({ entityType: 'Visit', entityNumber: visit.visitNumber, fromStatus: previousStatus, toStatus: 'Completed' });
  recordAudit({ module: 'Visits', action: 'COMPLETE', entityType: 'Visit', entityNumber: visit.visitNumber });
  saveDb();
  return toVisitRow(visit);
}

export async function batchCompleteVisits(visitNumbers, options = {}) {
  for (const visitNumber of visitNumbers) {
    await completeVisit(visitNumber, options);
  }
  return listVisits();
}

export async function rescheduleVisit(visitNumber, { newDate, newSlotId, reason, remarks = '' } = {}) {
  await delay(350);
  if (!newDate || !newSlotId || !reason) throw new Error('Date, slot, and reason are required.');

  const db = getDb();
  const visit = db.visits.find((item) => item.visitNumber === visitNumber);
  if (!visit) throw new Error('Visit not found.');
  if (visit.status === 'Completed') throw new Error('Completed visits cannot be rescheduled.');

  const oldDate = visit.date;
  visit.date = dayjs(newDate).toISOString();
  visit.slotId = newSlotId;
  visit.status = 'Scheduled';
  visit.rescheduleHistory = [
    ...(visit.rescheduleHistory || []),
    { fromDate: oldDate, toDate: visit.date, reason, remarks, changedOn: new Date().toISOString() },
  ];

  recordStatusChange({ entityType: 'Visit', entityNumber: visit.visitNumber, fromStatus: 'Scheduled', toStatus: 'Rescheduled', reason });
  recordAudit({ module: 'Visits', action: 'RESCHEDULE', entityType: 'Visit', entityNumber: visit.visitNumber, details: reason });
  saveDb();
  return { ...toVisitRow(visit), oldDate, newDate: visit.date };
}
