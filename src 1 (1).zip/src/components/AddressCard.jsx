import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Chip from '@mui/material/Chip';
import Button from '@mui/material/Button';
import PlaceOutlinedIcon from '@mui/icons-material/PlaceOutlined';
import EntityLink from './EntityLink';
import { serviceAreas } from '../api/masters';

export default function AddressCard({ address, onCreateBooking, onViewRelated }) {
  const area = serviceAreas.find((a) => a.id === address.area);

  return (
    <Paper variant="outlined" sx={{ p: 2 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
        <Stack direction="row" spacing={1} alignItems="center">
          <PlaceOutlinedIcon fontSize="small" color="action" />
          <Typography variant="subtitle1">{address.label}</Typography>
          {address.isDefault && <Chip size="small" label="Default" color="primary" variant="outlined" />}
          {address.status === 'Inactive' && <Chip size="small" label="Inactive" />}
        </Stack>
        <EntityLink type="Address" id={address.addressNumber} />
      </Stack>

      <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
        {[address.doorNo, address.block, address.community, address.addressLine].filter(Boolean).join(', ')}
      </Typography>
      <Typography variant="body2" color="text.secondary">
        {area?.name}{area ? ', ' : ''}{address.city} {address.pincode}
      </Typography>
      {address.landmark && (
        <Typography variant="caption" color="text.secondary">
          Landmark: {address.landmark}
        </Typography>
      )}

      <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
        <Button size="small" variant="outlined" onClick={() => onCreateBooking?.(address)}>
          Create Booking
        </Button>
        {onViewRelated && (
          <Button size="small" onClick={() => onViewRelated(address)}>
            View Related
          </Button>
        )}
      </Stack>
    </Paper>
  );
}
