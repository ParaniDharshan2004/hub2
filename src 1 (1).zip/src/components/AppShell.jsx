import { useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import InputBase from '@mui/material/InputBase';
import Avatar from '@mui/material/Avatar';
import Tooltip from '@mui/material/Tooltip';
import Divider from '@mui/material/Divider';
import Collapse from '@mui/material/Collapse';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme, alpha } from '@mui/material/styles';

import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import DashboardOutlinedIcon from '@mui/icons-material/DashboardOutlined';
import PeopleAltOutlinedIcon from '@mui/icons-material/PeopleAltOutlined';
import EventNoteOutlinedIcon from '@mui/icons-material/EventNoteOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import AutorenewOutlinedIcon from '@mui/icons-material/AutorenewOutlined';
import CleaningServicesOutlinedIcon from '@mui/icons-material/CleaningServicesOutlined';
import PaymentsOutlinedIcon from '@mui/icons-material/PaymentsOutlined';
import ReceiptLongOutlinedIcon from '@mui/icons-material/ReceiptLongOutlined';
import BarChartOutlinedIcon from '@mui/icons-material/BarChartOutlined';
import TuneOutlinedIcon from '@mui/icons-material/TuneOutlined';
import AdminPanelSettingsOutlinedIcon from '@mui/icons-material/AdminPanelSettingsOutlined';
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { initials } from '../utils/format';

const DRAWER_WIDTH = 248;

const NAV_ITEMS = [
  { label: 'Dashboard', to: '/dashboard', icon: DashboardOutlinedIcon },
  { label: 'Customers', to: '/customers', icon: PeopleAltOutlinedIcon },
  { label: 'Bookings', to: '/bookings', icon: EventNoteOutlinedIcon },
  { label: 'Subscriptions', to: '/subscriptions', icon: AutorenewOutlinedIcon },
  { label: 'Visits', to: '/visits', icon: CleaningServicesOutlinedIcon },
  { label: 'Visit Calendar', to: '/visits/calendar', icon: CalendarMonthOutlinedIcon },
  { label: 'Payments', to: '/payments', icon: PaymentsOutlinedIcon },
  { label: 'Invoices', to: '/invoices', icon: ReceiptLongOutlinedIcon },
  { label: 'Reports', to: '/reports', icon: BarChartOutlinedIcon },
  {
    label: 'Masters',
    icon: TuneOutlinedIcon,
    children: [
      'Service Offerings',
      'Bathroom Options',
      'Frequencies',
      'Plans',
      'Plan Prices',
      'Taxes',
      'Areas',
      'Service Slots',
      'Payment Modes',
      'Receiver Accounts',
      'Status Configuration',
    ].map((label) => ({ label, to: `/masters/${label.toLowerCase().replace(/\s+/g, '-')}` })),
  },
  {
    label: 'Administration',
    icon: AdminPanelSettingsOutlinedIcon,
    children: [
      { label: 'Users', to: '/admin/users' },
      { label: 'Roles', to: '/admin/roles' },
      { label: 'Permissions', to: '/admin/permissions' },
      { label: 'Audit Logs', to: '/admin/audit-logs' },
      { label: 'Status History', to: '/admin/status-history' },
    ],
  },
  { label: 'Settings', to: '/settings', icon: SettingsOutlinedIcon },
];

function NavGroup({ item, currentPath, onNavigate }) {
  const [openGroup, setOpenGroup] = useState(item.children.some((c) => currentPath.startsWith(c.to)));
  const Icon = item.icon;
  return (
    <>
      <ListItemButton onClick={() => setOpenGroup((o) => !o)} sx={{ color: 'inherit', mx: 1, borderRadius: 1.5 }}>
        <ListItemIcon sx={{ color: 'inherit', minWidth: 36, opacity: 0.85 }}>
          <Icon fontSize="small" />
        </ListItemIcon>
        <ListItemText primaryTypographyProps={{ fontSize: '0.9rem' }} primary={item.label} />
        {openGroup ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
      </ListItemButton>
      <Collapse in={openGroup} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          {item.children.map((child) => (
            <ListItemButton
              key={child.to}
              selected={currentPath === child.to}
              onClick={() => onNavigate(child.to)}
              sx={{ pl: 6.5, mx: 1, borderRadius: 1.5, color: 'inherit' }}
            >
              <ListItemText primaryTypographyProps={{ fontSize: '0.85rem' }} primary={child.label} />
            </ListItemButton>
          ))}
        </List>
      </Collapse>
    </>
  );
}

function DrawerContent({ currentPath, onNavigate }) {
  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Toolbar sx={{ gap: 1.25 }}>
        <Box
          sx={{
            width: 32,
            height: 32,
            borderRadius: '8px',
            bgcolor: 'secondary.main',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontWeight: 700,
            color: '#1A1A1A',
            fontFamily: 'IBM Plex Mono, monospace',
          }}
        >
          BC
        </Box>
        <Box>
          <Typography sx={{ fontWeight: 700, lineHeight: 1.1, fontSize: '0.95rem' }}>Bathroom Care</Typography>
          <Typography sx={{ fontSize: '0.7rem', opacity: 0.7 }}>Operations Console</Typography>
        </Box>
      </Toolbar>
      <Divider sx={{ borderColor: alpha('#EAF3F1', 0.12) }} />
      <List sx={{ flex: 1, py: 1, overflowY: 'auto' }}>
        {NAV_ITEMS.map((item) =>
          item.children ? (
            <NavGroup key={item.label} item={item} currentPath={currentPath} onNavigate={onNavigate} />
          ) : (
            <ListItemButton
              key={item.to}
              selected={currentPath.startsWith(item.to)}
              onClick={() => onNavigate(item.to)}
              sx={{
                mx: 1,
                mb: 0.25,
                borderRadius: 1.5,
                color: 'inherit',
                '&.Mui-selected': { bgcolor: alpha('#EAF3F1', 0.14) },
              }}
            >
              <ListItemIcon sx={{ color: 'inherit', minWidth: 36, opacity: 0.85 }}>
                <item.icon fontSize="small" />
              </ListItemIcon>
              <ListItemText primaryTypographyProps={{ fontSize: '0.9rem' }} primary={item.label} />
            </ListItemButton>
          )
        )}
      </List>
    </Box>
  );
}

export default function AppShell() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavigate = (to) => {
    navigate(to);
    if (isMobile) setMobileOpen(false);
  };

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <AppBar
        position="fixed"
        sx={{ width: { md: `calc(100% - ${DRAWER_WIDTH}px)` }, ml: { md: `${DRAWER_WIDTH}px` }, zIndex: theme.zIndex.drawer + 1 }}
      >
        <Toolbar sx={{ gap: 1.5 }}>
          <IconButton edge="start" onClick={() => setMobileOpen(true)} sx={{ display: { md: 'none' } }} aria-label="Open menu">
            <MenuIcon />
          </IconButton>

          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              bgcolor: 'background.default',
              borderRadius: 999,
              px: 1.5,
              py: 0.5,
              flex: 1,
              maxWidth: 480,
              border: '1px solid',
              borderColor: 'divider',
            }}
          >
            <SearchIcon fontSize="small" sx={{ color: 'text.secondary' }} />
            <InputBase
              placeholder="Search Customer ID, Booking ID, mobile, name…"
              sx={{ fontSize: '0.875rem', width: '100%' }}
              inputProps={{ 'aria-label': 'Global search' }}
            />
          </Box>

          <Box sx={{ flex: 1 }} />

          <Tooltip title="Demo Admin">
            <Avatar sx={{ width: 34, height: 34, fontSize: '0.8rem', bgcolor: 'primary.main' }}>
              {initials('Demo Admin')}
            </Avatar>
          </Tooltip>
        </Toolbar>
      </AppBar>

      <Box component="nav" sx={{ width: { md: DRAWER_WIDTH }, flexShrink: { md: 0 } }}>
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={() => setMobileOpen(false)}
          ModalProps={{ keepMounted: true }}
          sx={{ display: { xs: 'block', md: 'none' }, '& .MuiDrawer-paper': { width: DRAWER_WIDTH } }}
        >
          <DrawerContent currentPath={location.pathname} onNavigate={handleNavigate} />
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{ display: { xs: 'none', md: 'block' }, '& .MuiDrawer-paper': { width: DRAWER_WIDTH, boxSizing: 'border-box' } }}
          open
        >
          <DrawerContent currentPath={location.pathname} onNavigate={handleNavigate} />
        </Drawer>
      </Box>

      <Box
        component="main"
        sx={{
          flexGrow: 1,
          width: { md: `calc(100% - ${DRAWER_WIDTH}px)` },
          bgcolor: 'background.default',
          minHeight: '100vh',
        }}
      >
        <Toolbar />
        <Box sx={{ p: { xs: 2, sm: 3 }, maxWidth: 1400, mx: 'auto' }}>
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
}
