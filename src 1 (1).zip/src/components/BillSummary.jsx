import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Chip from '@mui/material/Chip';
import Money from './Money';
import { formatDate } from '../utils/format';

function Row({ label, value, muted, strong }) {
  return (
    <Stack direction="row" justifyContent="space-between">
      <Typography variant="body2" color={muted ? 'text.secondary' : 'text.primary'}>
        {label}
      </Typography>
      <Typography
        variant="body2"
        component="div"
        sx={{ fontWeight: strong ? 700 : 500 }}
      >
        <Money value={value} strong={strong} />
      </Typography>
    </Stack>
  );
}

export default function BillSummary({ quote, priceChanged }) {
  if (!quote) {
    return (
      <Paper variant="outlined" sx={{ p: 2.5 }}>
        <Typography variant="subtitle1" gutterBottom>
          Bill Summary
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Select a plan, frequency, and bathroom count to see pricing.
        </Typography>
      </Paper>
    );
  }

  return (
    <Paper variant="outlined" sx={{ p: 2.5, position: { md: 'sticky' }, top: { md: 88 } }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.5 }}>
        <Typography variant="subtitle1">Bill Summary</Typography>
        {priceChanged && <Chip size="small" color="warning" label="Price updated" />}
      </Stack>

      <Stack spacing={0.75}>
        <Row label={`Price per Service (${quote.numServices} services)`} value={quote.pricePerService} muted />
        <Row label="Service Charges" value={quote.serviceCharges} />
        {quote.authorizedDiscount > 0 && <Row label="Authorized Discount" value={-quote.authorizedDiscount} muted />}
        <Divider sx={{ my: 0.5 }} />
        <Row label="Taxable Amount" value={quote.taxableAmount} />
        {quote.taxes.map((t) => (
          <Row key={t.id} label={`${t.label} (${(t.rate * 100).toFixed(0)}%)`} value={t.amount} muted />
        ))}
        <Divider sx={{ my: 0.5 }} />
        <Row label="Total Amount" value={quote.total} strong />
      </Stack>

      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1.5 }}>
        Pricing effective {formatDate(quote.effectiveDate)}
      </Typography>
    </Paper>
  );
}
