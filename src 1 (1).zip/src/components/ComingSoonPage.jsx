import Paper from '@mui/material/Paper';
import PageHeader from './PageHeader';
import { EmptyState } from './PageStates';
import ConstructionOutlinedIcon from '@mui/icons-material/ConstructionOutlined';

export default function ComingSoonPage({ title, note }) {
  return (
    <>
      <PageHeader title={title} />
      <Paper variant="outlined">
        <EmptyState
          icon={<ConstructionOutlinedIcon sx={{ fontSize: 40, color: 'text.secondary', mb: 1 }} />}
          title="Coming up in the next phase"
          description={
            note ||
            'Customers, Bookings, and Subscriptions are built first per the agreed sequence. This screen follows next.'
          }
        />
      </Paper>
    </>
  );
}
