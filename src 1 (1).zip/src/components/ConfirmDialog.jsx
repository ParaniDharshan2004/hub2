import { useState } from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogActions from '@mui/material/DialogActions';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import CircularProgress from '@mui/material/CircularProgress';

export default function ConfirmDialog({
  open,
  title,
  description,
  entityLabel,
  requireReason = false,
  confirmLabel = 'Confirm',
  destructive = false,
  onConfirm,
  onClose,
  children,
  confirmDisabled = false,
}) {
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleConfirm = async () => {
    setSubmitting(true);
    try {
      await onConfirm(reason);
      setReason('');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onClose={submitting ? undefined : onClose} maxWidth="xs" fullWidth>
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <DialogContentText sx={{ mb: entityLabel ? 1 : 0 }}>{description}</DialogContentText>
        {entityLabel && (
          <DialogContentText sx={{ fontFamily: 'IBM Plex Mono, monospace', fontWeight: 600, color: 'text.primary' }}>
            {entityLabel}
          </DialogContentText>
        )}
        {requireReason && (
          <TextField
            fullWidth
            multiline
            minRows={2}
            label="Reason"
            sx={{ mt: 2 }}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          />
        )}
        {children}
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} disabled={submitting}>
          Cancel
        </Button>
        <Button
          variant="contained"
          color={destructive ? 'error' : 'primary'}
          onClick={handleConfirm}
          disabled={submitting || confirmDisabled || (requireReason && !reason.trim())}
          startIcon={submitting ? <CircularProgress size={16} color="inherit" /> : null}
        >
          {confirmLabel}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
