import { Link as RouterLink } from 'react-router-dom';
import Box from '@mui/material/Box';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';

const ROUTES = {
  Customer: (id) => `/customers/${id}`,
  Booking: (id) => `/bookings/${id}`,
  Subscription: (id) => `/subscriptions/${id}`,
};

// Renders a business ID (never a raw database id) as a copyable, routable
// link, per the "every business ID must be copyable, keyboard accessible,
// and rendered through EntityLink" requirement.
export default function EntityLink({ type, id, label }) {
  const routeFn = ROUTES[type];
  const display = label || id;

  const handleCopy = (e) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard?.writeText(id);
  };

  const content = (
    <Box
      component="span"
      sx={{
        fontFamily: 'IBM Plex Mono, monospace',
        fontWeight: 600,
        fontSize: '0.85rem',
        color: 'primary.dark',
      }}
    >
      {display}
    </Box>
  );

  return (
    <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.25 }}>
      {routeFn ? (
        <Box component={RouterLink} to={routeFn(id)} sx={{ textDecoration: 'none' }}>
          {content}
        </Box>
      ) : (
        content
      )}
      <Tooltip title="Copy ID">
        <IconButton size="small" onClick={handleCopy} aria-label={`Copy ${id}`}>
          <ContentCopyIcon sx={{ fontSize: 14 }} />
        </IconButton>
      </Tooltip>
    </Box>
  );
}
