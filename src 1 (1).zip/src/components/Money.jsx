import Box from '@mui/material/Box';
import { formatMoney } from '../utils/format';

export default function Money({ value, strong = false }) {
  return (
    <Box
      component="span"
      sx={{
        fontFamily: 'IBM Plex Mono, monospace',
        fontWeight: strong ? 700 : 500,
        fontVariantNumeric: 'tabular-nums',
      }}
    >
      {formatMoney(value)}
    </Box>
  );
}
