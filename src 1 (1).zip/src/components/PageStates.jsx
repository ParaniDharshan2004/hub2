import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import CircularProgress from '@mui/material/CircularProgress';
import Skeleton from '@mui/material/Skeleton';
import InboxOutlinedIcon from '@mui/icons-material/InboxOutlined';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';

export function LoadingSkeleton({ rows = 5 }) {
  return (
    <Stack spacing={1.25} sx={{ py: 2 }}>
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} variant="rounded" height={44} />
      ))}
    </Stack>
  );
}

export function InlineSpinner({ label = 'Loading…' }) {
  return (
    <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="center" sx={{ py: 6 }}>
      <CircularProgress size={20} />
      <Typography variant="body2" color="text.secondary">
        {label}
      </Typography>
    </Stack>
  );
}

export function EmptyState({ title, description, actionLabel, onAction, icon }) {
  return (
    <Box sx={{ textAlign: 'center', py: 8, px: 2 }}>
      {icon || <InboxOutlinedIcon sx={{ fontSize: 40, color: 'text.secondary', mb: 1 }} />}
      <Typography variant="h4" sx={{ mb: 0.5 }}>
        {title}
      </Typography>
      {description && (
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2, maxWidth: 420, mx: 'auto' }}>
          {description}
        </Typography>
      )}
      {actionLabel && (
        <Button variant="contained" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </Box>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <Box sx={{ textAlign: 'center', py: 8, px: 2 }}>
      <ErrorOutlineIcon sx={{ fontSize: 40, color: 'error.main', mb: 1 }} />
      <Typography variant="h4" sx={{ mb: 0.5 }}>
        Something went wrong
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        {message || 'Please try again.'}
      </Typography>
      {onRetry && (
        <Button variant="outlined" onClick={onRetry}>
          Retry
        </Button>
      )}
    </Box>
  );
}

export function NoPermissionState() {
  return (
    <Box sx={{ textAlign: 'center', py: 8, px: 2 }}>
      <LockOutlinedIcon sx={{ fontSize: 40, color: 'text.secondary', mb: 1 }} />
      <Typography variant="h4" sx={{ mb: 0.5 }}>
        You don't have access to this
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Ask an administrator to grant the required permission.
      </Typography>
    </Box>
  );
}
