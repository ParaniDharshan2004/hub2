/**
 * RolesPage.jsx
 * -----------------------------------------------------------------------
 * Roles master screen (Tomorrow Phase item, built on request).
 * List, search, view, create, edit, activate, deactivate. No hard delete.
 * The three base system roles (SUPER_ADMIN, ADMIN, USER) are seeded and
 * protected: not editable, not deactivatable, code is fixed.
 *
 * INTEGRATION NOTES:
 *  - Swap `useMockRoles()` for a real `useRoles()` hook backed by a
 *    `role.service.js` (GET/POST/PATCH /roles, /roles/:id/activate,
 *    /roles/:id/deactivate).
 *  - Swap `useMockPermissions()` for the real `usePermissions()`.
 *  - Permission codes assumed for this screen: ROLE.VIEW, ROLE.CREATE,
 *    ROLE.UPDATE, ROLE.ACTIVATE, ROLE.DEACTIVATE.
 * -----------------------------------------------------------------------
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Box, Stack, Paper, Grid, Typography, Breadcrumbs, Link as MLink,
  Button, IconButton, Tooltip, TextField, MenuItem, InputAdornment,
  Chip, Drawer, Dialog, DialogTitle, DialogContent, DialogActions,
  Divider, Snackbar, Alert, Menu, List, ListItem, ListItemText,
} from "@mui/material";
import { alpha } from "@mui/material/styles";
import {
  DataGrid, GridToolbarColumnsButton, GridToolbarContainer, GridToolbarDensitySelector,
} from "@mui/x-data-grid";
import dayjs from "dayjs";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import AddIcon from "@mui/icons-material/Add";
import CloseIcon from "@mui/icons-material/Close";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";
import RefreshIcon from "@mui/icons-material/Refresh";
import FilterAltOffIcon from "@mui/icons-material/FilterAltOff";
import SearchIcon from "@mui/icons-material/Search";
import LockIcon from "@mui/icons-material/Lock";
import RuleIcon from "@mui/icons-material/Rule";

const COLORS = {
  primary: "#1D89C8", secondary: "#3EB8AF", heading: "#123B56",
  pageBg: "#F7FBFD", panelBg: "#EAF7FC", danger: "#C62828",
  amber: "#B26A00", green: "#1E7E34", gray: "#667085",
};

/* ------------------------------ Mock data ----------------------------- */
const ALL_PERMISSIONS = [
  "MASTER.COMPONENT.VIEW", "MASTER.COMPONENT.CREATE", "MASTER.COMPONENT.UPDATE",
  "MASTER.COMPONENT.ACTIVATE", "MASTER.COMPONENT.DEACTIVATE",
  "MASTER.SUBCOMPONENT.VIEW", "MASTER.SUBCOMPONENT.CREATE", "MASTER.SUBCOMPONENT.UPDATE",
  "MASTER.SUBCOMPONENT.ACTIVATE", "MASTER.SUBCOMPONENT.DEACTIVATE",
  "USER.VIEW", "USER.CREATE", "USER.UPDATE", "USER.ACTIVATE", "USER.DEACTIVATE", "USER.PERMISSION.VIEW",
  "PETTY_CASH.ENTRY.VIEW", "PETTY_CASH.ENTRY.CREATE", "PETTY_CASH.ENTRY.UPDATE_DRAFT",
  "PETTY_CASH.ENTRY.POST", "PETTY_CASH.ENTRY.VOID",
  "PETTY_CASH.REIMBURSEMENT.CREATE", "PETTY_CASH.REIMBURSEMENT.VIEW",
];

function seedMockRoles() {
  return [
    {
      id: "role-super-admin", roleCode: "SUPER_ADMIN", roleName: "Super Admin",
      description: "Full access to every current-phase screen and operation.",
      isSystemRole: true, isActive: true, permissionCodes: [...ALL_PERMISSIONS],
      version: 1, createdAt: dayjs().subtract(120, "day").toISOString(), updatedAt: dayjs().subtract(5, "day").toISOString(),
    },
    {
      id: "role-admin", roleCode: "ADMIN", roleName: "Admin",
      description: "Can view all modules; create/update/post/void only when explicitly granted.",
      isSystemRole: true, isActive: true,
      permissionCodes: ["MASTER.COMPONENT.VIEW", "MASTER.SUBCOMPONENT.VIEW", "USER.VIEW", "PETTY_CASH.ENTRY.VIEW"],
      version: 1, createdAt: dayjs().subtract(120, "day").toISOString(), updatedAt: dayjs().subtract(10, "day").toISOString(),
    },
    {
      id: "role-user", roleCode: "USER", roleName: "User",
      description: "Day-to-day Petty Cash operator with limited create/edit rights.",
      isSystemRole: true, isActive: true,
      permissionCodes: ["PETTY_CASH.ENTRY.VIEW"],
      version: 1, createdAt: dayjs().subtract(120, "day").toISOString(), updatedAt: dayjs().subtract(15, "day").toISOString(),
    },
    {
      id: "role-branch-cashier", roleCode: "BRANCH_CASHIER", roleName: "Branch Cashier",
      description: "Custom role for branch-level petty cash handling.",
      isSystemRole: false, isActive: true,
      permissionCodes: ["PETTY_CASH.ENTRY.VIEW", "PETTY_CASH.ENTRY.CREATE"],
      version: 1, createdAt: dayjs().subtract(30, "day").toISOString(), updatedAt: dayjs().subtract(2, "day").toISOString(),
    },
    {
      id: "role-auditor", roleCode: "AUDITOR", roleName: "Auditor",
      description: "Read-only visibility across financial and master data.",
      isSystemRole: false, isActive: false,
      permissionCodes: ["PETTY_CASH.ENTRY.VIEW", "MASTER.COMPONENT.VIEW", "MASTER.SUBCOMPONENT.VIEW"],
      version: 1, createdAt: dayjs().subtract(60, "day").toISOString(), updatedAt: dayjs().subtract(40, "day").toISOString(),
    },
  ];
}

function delay(ms) { return new Promise((r) => setTimeout(r, ms)); }

/* ------------------------------ Mock hooks ----------------------------- */
function useMockPermissions() {
  const granted = useMemo(() => new Set(["ROLE.VIEW", "ROLE.CREATE", "ROLE.UPDATE", "ROLE.ACTIVATE", "ROLE.DEACTIVATE"]), []);
  const can = useCallback((c) => granted.has(c), [granted]);
  return { can };
}

function useMockSnackbar() {
  const [state, setState] = useState({ open: false, message: "", severity: "success" });
  const notify = useCallback((message, severity = "success") => setState({ open: true, message, severity }), []);
  const close = useCallback(() => setState((s) => ({ ...s, open: false })), []);
  return { state, notify, close };
}

const DEFAULT_FILTERS = { search: "", status: "ALL" };

function useMockRoles() {
  const allRef = useRef(seedMockRoles());
  const [data, setData] = useState([]);
  const [rowCount, setRowCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [pagination, setPagination] = useState({ page: 0, pageSize: 10 });

  const applyFilters = useCallback((rows, f) => rows.filter((r) => {
    if (f.search) {
      const hay = `${r.roleCode} ${r.roleName} ${r.description}`.toLowerCase();
      if (!hay.includes(f.search.toLowerCase())) return false;
    }
    if (f.status !== "ALL" && String(r.isActive) !== f.status) return false;
    return true;
  }), []);

  const reload = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      await delay(300);
      const filtered = applyFilters(allRef.current, filters);
      const start = pagination.page * pagination.pageSize;
      setRowCount(filtered.length);
      setData(filtered.slice(start, start + pagination.pageSize));
    } catch { setError({ message: "Unable to load roles." }); }
    finally { setLoading(false); }
  }, [applyFilters, filters, pagination]);

  useEffect(() => { reload(); }, [filters, pagination]); // eslint-disable-line react-hooks/exhaustive-deps

  const createRecord = useCallback(async (payload) => {
    await delay(350);
    const record = {
      id: `role-${allRef.current.length}`, version: 1, isSystemRole: false, isActive: true,
      permissionCodes: [], ...payload, createdAt: dayjs().toISOString(), updatedAt: dayjs().toISOString(),
    };
    allRef.current = [record, ...allRef.current];
    return record;
  }, []);

  const updateRecord = useCallback(async (id, payload, version) => {
    await delay(300);
    let updated = null;
    allRef.current = allRef.current.map((r) => {
      if (r.id !== id) return r;
      if (r.version !== version) { const e = new Error("Version conflict"); e.status = 409; throw e; }
      updated = { ...r, ...payload, version: r.version + 1, updatedAt: dayjs().toISOString() };
      return updated;
    });
    return updated;
  }, []);

  const activateRecord = useCallback(async (id, version) => {
    await delay(300);
    allRef.current = allRef.current.map((r) => (r.id === id ? { ...r, isActive: true, version: r.version + 1, updatedAt: dayjs().toISOString() } : r));
  }, []);

  const deactivateRecord = useCallback(async (id, version, reason) => {
    await delay(300);
    allRef.current = allRef.current.map((r) => (r.id === id ? { ...r, isActive: false, version: r.version + 1, deactivationReason: reason, updatedAt: dayjs().toISOString() } : r));
  }, []);

  return { data, rowCount, loading, error, pagination, setPagination, filters, setFilters, reload, createRecord, updateRecord, activateRecord, deactivateRecord };
}

/* ------------------------------ Presentational ----------------------------- */
function BooleanFlag({ value, trueLabel = "Yes", falseLabel = "No" }) {
  return (
    <Chip size="small" label={value ? trueLabel : falseLabel}
      sx={{ color: value ? COLORS.green : COLORS.gray, backgroundColor: alpha(value ? COLORS.green : COLORS.gray, 0.1), height: 20, fontSize: 11 }} />
  );
}
function StatusChip({ isActive }) {
  return (
    <Chip size="small" label={isActive ? "Active" : "Inactive"}
      sx={{ color: isActive ? COLORS.green : COLORS.gray, backgroundColor: alpha(isActive ? COLORS.green : COLORS.gray, 0.12), fontWeight: 600, height: 22, fontSize: 12 }} />
  );
}
function formatDateTime(v) { return v ? dayjs(v).format("DD MMM YYYY, hh:mm A") : "—"; }
function CustomToolbar() {
  return <GridToolbarContainer sx={{ px: 1, py: 0.5 }}><GridToolbarColumnsButton /><GridToolbarDensitySelector /></GridToolbarContainer>;
}

/* ------------------------------ Validation ----------------------------- */
const roleSchema = yup.object({
  roleCode: yup.string().trim().matches(/^[A-Z0-9_]+$/, "Use uppercase letters, numbers, and underscore only.").max(40).required("Role code is required."),
  roleName: yup.string().trim().max(80).required("Role name is required."),
  description: yup.string().max(240, "Maximum 240 characters."),
});

/* ------------------------------ Form Drawer ----------------------------- */
function RoleFormDrawer({ open, mode, record, onClose, onSubmit, onRequestUnsavedGuard, submitting }) {
  const isEdit = mode === "edit";
  const { control, handleSubmit, reset, formState: { errors, isDirty } } = useForm({
    resolver: yupResolver(roleSchema),
    defaultValues: { roleCode: "", roleName: "", description: "" },
  });

  useEffect(() => {
    if (open) {
      reset(isEdit && record
        ? { roleCode: record.roleCode, roleName: record.roleName, description: record.description }
        : { roleCode: "", roleName: "", description: "" });
    }
  }, [open, isEdit, record, reset]);

  const attemptClose = () => (isDirty ? onRequestUnsavedGuard(onClose) : onClose());
  const submit = handleSubmit((values) => onSubmit(values));

  return (
    <Drawer anchor="right" open={open} onClose={attemptClose}>
      <Box sx={{ width: { xs: "100vw", sm: 460 }, display: "flex", flexDirection: "column", height: "100%" }}>
        <Box sx={{ p: 2, display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #eee" }}>
          <Typography variant="h6" sx={{ color: COLORS.heading, fontWeight: 700 }}>{isEdit ? "Edit Role" : "New Role"}</Typography>
          <IconButton aria-label="Close drawer" onClick={attemptClose}><CloseIcon /></IconButton>
        </Box>
        <Box sx={{ p: 2, overflowY: "auto", flex: 1 }}>
          <Stack spacing={2}>
            <Controller name="roleCode" control={control} render={({ field }) => (
              <TextField {...field} label="Role Code" required fullWidth disabled={isEdit}
                error={!!errors.roleCode} helperText={errors.roleCode?.message || "Fixed once created, e.g. BRANCH_CASHIER."} />
            )} />
            <Controller name="roleName" control={control} render={({ field }) => (
              <TextField {...field} label="Role Name" required fullWidth error={!!errors.roleName} helperText={errors.roleName?.message} />
            )} />
            <Controller name="description" control={control} render={({ field }) => (
              <TextField {...field} label="Description" fullWidth multiline minRows={3} error={!!errors.description} helperText={errors.description?.message} />
            )} />
            <Alert severity="info">
              Permission assignment for this role is managed on the Role–Permission Matrix screen after the role is created.
            </Alert>
          </Stack>
        </Box>
        <Divider />
        <Stack direction="row" spacing={1.5} sx={{ p: 2 }}>
          <Button variant="outlined" fullWidth onClick={attemptClose} disabled={submitting}>Cancel</Button>
          <Button variant="contained" fullWidth onClick={submit} disabled={submitting} sx={{ bgcolor: COLORS.primary }}>
            {isEdit ? "Save changes" : "Create"}
          </Button>
        </Stack>
      </Box>
    </Drawer>
  );
}

/* ------------------------------ Deactivate Dialog ----------------------------- */
function DeactivateDialog({ open, record, onClose, onConfirm, submitting }) {
  const [reason, setReason] = useState("");
  useEffect(() => { if (open) setReason(""); }, [open]);
  if (!record) return null;
  const canSubmit = reason.trim().length >= 5;
  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle sx={{ fontWeight: 700 }}>Deactivate role?</DialogTitle>
      <DialogContent>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          "{record.roleName}" will no longer be assignable to Users. Users already holding this role keep their
          current effective permissions until reassigned; historical references remain visible.
        </Typography>
        <TextField label="Reason" required fullWidth multiline minRows={2} value={reason} onChange={(e) => setReason(e.target.value)} helperText="Minimum 5 characters." />
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} disabled={submitting}>Cancel</Button>
        <Button variant="contained" color="error" onClick={() => onConfirm(reason)} disabled={submitting || !canSubmit}>Deactivate</Button>
      </DialogActions>
    </Dialog>
  );
}

/* ------------------------------ Detail Drawer ----------------------------- */
function RoleDetailDrawer({ open, record, onClose, can, onEdit, onActivate, onDeactivate }) {
  if (!record) return null;
  const Row = ({ label, value }) => (
    <Stack direction="row" justifyContent="space-between" sx={{ py: 0.75 }}>
      <Typography variant="body2" color="text.secondary">{label}</Typography>
      <Typography variant="body2" fontWeight={600} sx={{ textAlign: "right" }}>{value ?? "—"}</Typography>
    </Stack>
  );
  return (
    <Drawer anchor="right" open={open} onClose={onClose}>
      <Box sx={{ width: { xs: "100vw", sm: 460 }, height: "100%", display: "flex", flexDirection: "column" }}>
        <Box sx={{ p: 2, display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #eee" }}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Typography variant="h6" sx={{ color: COLORS.heading, fontWeight: 700 }}>{record.roleName}</Typography>
            <StatusChip isActive={record.isActive} />
            {record.isSystemRole && <Chip size="small" icon={<LockIcon sx={{ fontSize: 14 }} />} label="System" />}
          </Stack>
          <IconButton aria-label="Close details" onClick={onClose}><CloseIcon /></IconButton>
        </Box>
        <Box sx={{ p: 2, overflowY: "auto", flex: 1 }}>
          <Row label="Role code" value={record.roleCode} />
          <Row label="Description" value={record.description} />
          <Row label="Assigned permissions" value={record.permissionCodes.length} />
          <Divider sx={{ my: 1.5 }} />
          <Typography variant="overline" color="text.secondary">Permission codes</Typography>
          <List dense sx={{ maxHeight: 260, overflowY: "auto" }}>
            {record.permissionCodes.length === 0 && (
              <Typography variant="body2" color="text.secondary" sx={{ py: 1 }}>No permissions assigned.</Typography>
            )}
            {record.permissionCodes.map((p) => (
              <ListItem key={p} disableGutters sx={{ py: 0.25 }}>
                <ListItemText primaryTypographyProps={{ variant: "body2" }} primary={p} />
              </ListItem>
            ))}
          </List>
          <Divider sx={{ my: 1.5 }} />
          <Row label="Created" value={formatDateTime(record.createdAt)} />
          <Row label="Updated" value={formatDateTime(record.updatedAt)} />
        </Box>
        <Divider />
        <Stack direction="row" spacing={1.5} sx={{ p: 2 }}>
          {!record.isSystemRole && can("ROLE.UPDATE") && (
            <Button variant="outlined" fullWidth startIcon={<EditIcon />} onClick={() => onEdit(record)}>Edit</Button>
          )}
          {!record.isSystemRole && record.isActive && can("ROLE.DEACTIVATE") && (
            <Button variant="contained" color="error" fullWidth startIcon={<ToggleOffIcon />} onClick={() => onDeactivate(record)}>Deactivate</Button>
          )}
          {!record.isSystemRole && !record.isActive && can("ROLE.ACTIVATE") && (
            <Button variant="contained" fullWidth startIcon={<ToggleOnIcon />} onClick={() => onActivate(record)} sx={{ bgcolor: COLORS.primary }}>Activate</Button>
          )}
        </Stack>
      </Box>
    </Drawer>
  );
}

function UnsavedChangesDialog({ open, onDiscard, onKeepEditing }) {
  return (
    <Dialog open={open} onClose={onKeepEditing} maxWidth="xs" fullWidth>
      <DialogTitle sx={{ fontWeight: 700 }}>Discard unsaved changes?</DialogTitle>
      <DialogContent><Typography variant="body2" color="text.secondary">You have unsaved changes. Leaving now will discard them.</Typography></DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onKeepEditing}>Continue editing</Button>
        <Button color="error" variant="contained" onClick={onDiscard}>Discard changes</Button>
      </DialogActions>
    </Dialog>
  );
}

function RowActionsMenu({ row, can, onView, onEdit, onActivate, onDeactivate }) {
  const [anchorEl, setAnchorEl] = useState(null);
  const close = () => setAnchorEl(null);
  return (
    <>
      <Tooltip title="More actions">
        <IconButton size="small" aria-label={`Actions for ${row.roleName}`} onClick={(e) => setAnchorEl(e.currentTarget)}><MoreVertIcon fontSize="small" /></IconButton>
      </Tooltip>
      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={close}>
        <MenuItem onClick={() => { close(); onView(row); }}><VisibilityIcon fontSize="small" sx={{ mr: 1 }} /> View</MenuItem>
        {!row.isSystemRole && can("ROLE.UPDATE") && (
          <MenuItem onClick={() => { close(); onEdit(row); }}><EditIcon fontSize="small" sx={{ mr: 1 }} /> Edit</MenuItem>
        )}
        {!row.isSystemRole && row.isActive && can("ROLE.DEACTIVATE") && (
          <MenuItem onClick={() => { close(); onDeactivate(row); }} sx={{ color: COLORS.danger }}><ToggleOffIcon fontSize="small" sx={{ mr: 1 }} /> Deactivate</MenuItem>
        )}
        {!row.isSystemRole && !row.isActive && can("ROLE.ACTIVATE") && (
          <MenuItem onClick={() => { close(); onActivate(row); }}><ToggleOnIcon fontSize="small" sx={{ mr: 1 }} /> Activate</MenuItem>
        )}
      </Menu>
    </>
  );
}

function FiltersBar({ filters, setFilters }) {
  const [local, setLocal] = useState(filters);
  const debounceRef = useRef(null);
  const updateSearch = (value) => {
    setLocal((s) => ({ ...s, search: value }));
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setFilters((f) => ({ ...f, search: value })), 350);
  };
  const apply = (patch) => { const next = { ...local, ...patch }; setLocal(next); setFilters(next); };
  const reset = () => { setLocal(DEFAULT_FILTERS); setFilters(DEFAULT_FILTERS); };
  return (
    <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2, mb: 2 }}>
      <Grid container spacing={1.5} alignItems="center">
        <Grid item xs={12} sm={6} md={4}>
          <TextField fullWidth size="small" placeholder="Search role code, name, description" value={local.search}
            onChange={(e) => updateSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
        </Grid>
        <Grid item xs={6} sm={3} md={2}>
          <TextField select fullWidth size="small" label="Status" value={local.status} onChange={(e) => apply({ status: e.target.value })}>
            <MenuItem value="ALL">All</MenuItem>
            <MenuItem value="true">Active</MenuItem>
            <MenuItem value="false">Inactive</MenuItem>
          </TextField>
        </Grid>
        <Grid item xs={6} sm={3} md={2}>
          <Button size="small" startIcon={<FilterAltOffIcon />} onClick={reset}>Reset filters</Button>
        </Grid>
      </Grid>
    </Paper>
  );
}

/* ------------------------------ Main page ----------------------------- */
export default function RolesPage() {
  const { can } = useMockPermissions();
  const snackbar = useMockSnackbar();
  const {
    data, rowCount, loading, error, pagination, setPagination, filters, setFilters,
    reload, createRecord, updateRecord, activateRecord, deactivateRecord,
  } = useMockRoles();

  const [formDrawer, setFormDrawer] = useState({ open: false, mode: "create", record: null });
  const [detailDrawer, setDetailDrawer] = useState({ open: false, record: null });
  const [deactivateDialog, setDeactivateDialog] = useState({ open: false, record: null });
  const [unsavedGuard, setUnsavedGuard] = useState({ open: false, onDiscard: null });
  const [submitting, setSubmitting] = useState(false);

  const openCreate = () => setFormDrawer({ open: true, mode: "create", record: null });
  const openEdit = (record) => setFormDrawer({ open: true, mode: "edit", record });
  const closeForm = () => setFormDrawer((s) => ({ ...s, open: false }));
  const requestUnsavedGuard = (onDiscard) => setUnsavedGuard({ open: true, onDiscard });

  const submitForm = async (values) => {
    setSubmitting(true);
    try {
      if (formDrawer.mode === "create") { await createRecord(values); snackbar.notify("Role created successfully."); }
      else { await updateRecord(formDrawer.record.id, values, formDrawer.record.version); snackbar.notify("Changes saved successfully."); }
      closeForm(); reload();
    } catch (e) {
      snackbar.notify(e.status === 409 ? "This role changed since you opened it. Reload and retry." : "Unable to save role.", "error");
    } finally { setSubmitting(false); }
  };

  const doActivate = async (row) => {
    setSubmitting(true);
    try { await activateRecord(row.id, row.version); snackbar.notify("Role activated successfully."); setDetailDrawer({ open: false, record: null }); reload(); }
    catch { snackbar.notify("Unable to activate role.", "error"); }
    finally { setSubmitting(false); }
  };

  const doDeactivate = async (reason) => {
    setSubmitting(true);
    try {
      await deactivateRecord(deactivateDialog.record.id, deactivateDialog.record.version, reason);
      snackbar.notify("Role deactivated successfully.");
      setDeactivateDialog({ open: false, record: null });
      setDetailDrawer({ open: false, record: null });
      reload();
    } catch { snackbar.notify("Unable to deactivate role.", "error"); }
    finally { setSubmitting(false); }
  };

  const columns = useMemo(() => [
    { field: "roleCode", headerName: "Role Code", width: 160 },
    { field: "roleName", headerName: "Role Name", width: 170 },
    { field: "description", headerName: "Description", width: 260 },
    { field: "isSystemRole", headerName: "System Role", width: 120, renderCell: (p) => <BooleanFlag value={p.value} /> },
    { field: "permissionCodes", headerName: "Permissions", width: 110, align: "right", headerAlign: "right", valueGetter: (p) => p.row.permissionCodes.length },
    { field: "isActive", headerName: "Status", width: 100, renderCell: (p) => <StatusChip isActive={p.value} /> },
    { field: "updatedAt", headerName: "Updated", width: 170, valueFormatter: (p) => formatDateTime(p.value) },
    {
      field: "actions", headerName: "Actions", width: 90, sortable: false, filterable: false, align: "right", headerAlign: "right",
      renderCell: (p) => (
        <RowActionsMenu row={p.row} can={can}
          onView={(row) => setDetailDrawer({ open: true, record: row })}
          onEdit={(row) => openEdit(row)}
          onActivate={(row) => doActivate(row)}
          onDeactivate={(row) => setDeactivateDialog({ open: true, record: row })}
        />
      ),
    },
  ], [can]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Box sx={{ bgcolor: COLORS.pageBg, minHeight: "100%", p: { xs: 1.5, sm: 3 } }}>
      <Breadcrumbs sx={{ mb: 1 }}>
        <MLink underline="hover" color="inherit" href="#">Access Control</MLink>
        <Typography color="text.primary">Roles</Typography>
      </Breadcrumbs>
      <Stack direction={{ xs: "column", sm: "row" }} justifyContent="space-between" alignItems={{ sm: "center" }} spacing={1.5} sx={{ mb: 2 }}>
        <Box>
          <Typography variant="h5" sx={{ color: COLORS.heading, fontWeight: 700 }}>Roles</Typography>
          <Typography variant="body2" color="text.secondary">Default permission bundles assignable to Users. Base roles are system-protected.</Typography>
        </Box>
        <Stack direction="row" spacing={1}>
          <Tooltip title="Refresh"><IconButton onClick={reload} aria-label="Refresh roles"><RefreshIcon /></IconButton></Tooltip>
          <Tooltip title="Open Role–Permission Matrix"><IconButton aria-label="Open role permission matrix"><RuleIcon /></IconButton></Tooltip>
          {can("ROLE.CREATE") && (
            <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate} sx={{ bgcolor: COLORS.primary }}>Add Role</Button>
          )}
        </Stack>
      </Stack>

      <FiltersBar filters={filters} setFilters={setFilters} />

      {error && <Alert severity="error" sx={{ mb: 2 }} action={<Button size="small" onClick={reload}>Retry</Button>}>{error.message}</Alert>}

      <Paper variant="outlined" sx={{ borderRadius: 2, overflow: "hidden" }}>
        <DataGrid
          autoHeight rows={data} columns={columns} loading={loading} density="compact" rowHeight={40}
          disableRowSelectionOnClick paginationMode="server" rowCount={rowCount}
          paginationModel={pagination} onPaginationModelChange={setPagination} pageSizeOptions={[10, 25, 50]}
          slots={{ toolbar: CustomToolbar }}
          sx={{ border: 0, "& .MuiDataGrid-cell": { py: "4px", px: "8px" }, "& .MuiDataGrid-columnHeaders": { bgcolor: COLORS.panelBg } }}
          localeText={{ noRowsLabel: "No roles found." }}
        />
      </Paper>

      <RoleFormDrawer open={formDrawer.open} mode={formDrawer.mode} record={formDrawer.record} onClose={closeForm}
        onSubmit={submitForm} onRequestUnsavedGuard={requestUnsavedGuard} submitting={submitting} />

      <RoleDetailDrawer open={detailDrawer.open} record={detailDrawer.record} onClose={() => setDetailDrawer({ open: false, record: null })}
        can={can} onEdit={(r) => { setDetailDrawer({ open: false, record: null }); openEdit(r); }}
        onActivate={doActivate} onDeactivate={(r) => setDeactivateDialog({ open: true, record: r })} />

      <DeactivateDialog open={deactivateDialog.open} record={deactivateDialog.record}
        onClose={() => setDeactivateDialog({ open: false, record: null })} onConfirm={doDeactivate} submitting={submitting} />

      <UnsavedChangesDialog open={unsavedGuard.open} onKeepEditing={() => setUnsavedGuard({ open: false, onDiscard: null })}
        onDiscard={() => { unsavedGuard.onDiscard && unsavedGuard.onDiscard(); setUnsavedGuard({ open: false, onDiscard: null }); }} />

      <Snackbar open={snackbar.state.open} autoHideDuration={4000} onClose={snackbar.close} anchorOrigin={{ vertical: "bottom", horizontal: "center" }}>
        <Alert onClose={snackbar.close} severity={snackbar.state.severity} sx={{ width: "100%" }}>{snackbar.state.message}</Alert>
      </Snackbar>
    </Box>
  );
}
