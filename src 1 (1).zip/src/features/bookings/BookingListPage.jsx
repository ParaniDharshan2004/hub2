import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import InputAdornment from '@mui/material/InputAdornment';
import Button from '@mui/material/Button';
import { DataGrid } from '@mui/x-data-grid';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';

import PageHeader from '../../components/PageHeader';
import EntityLink from '../../components/EntityLink';
import StatusChip from '../../components/StatusChip';
import Money from '../../components/Money';
import { EmptyState, ErrorState } from '../../components/PageStates';
import { listBookings } from '../../api/bookings';
import { serviceAreas, plans, frequencies } from '../../api/masters';
import { formatDate } from '../../utils/format';

export default function BookingListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['bookings', search, status],
    queryFn: () => listBookings({ search, status }),
  });

  const columns = useMemo(
    () => [
      { field: 'bookingNumber', headerName: 'Booking ID', width: 190, renderCell: (p) => <EntityLink type="Booking" id={p.value} /> },
      { field: 'type', headerName: 'Type', width: 90 },
      {
        field: 'customer',
        headerName: 'Customer',
        flex: 1,
        minWidth: 160,
        valueGetter: (v, row) => (row.customer ? `${row.customer.name} (${row.customer.customerNumber})` : '—'),
      },
      {
        field: 'address',
        headerName: 'Area',
        width: 130,
        valueGetter: (v, row) => serviceAreas.find((a) => a.id === row.address?.area)?.name || '—',
      },
      { field: 'bathrooms', headerName: 'Bathrooms', width: 100, type: 'number' },
      {
        field: 'frequencyId',
        headerName: 'Frequency',
        width: 110,
        valueGetter: (v, row) => frequencies.find((f) => f.id === row.frequencyId)?.name || '—',
      },
      {
        field: 'planId',
        headerName: 'Plan',
        width: 150,
        valueGetter: (v, row) => plans.find((p) => p.id === row.planId)?.name || '—',
      },
      { field: 'total', headerName: 'Total Amount', width: 130, renderCell: (p) => <Money value={p.value} /> },
      { field: 'startDate', headerName: 'Start Date', width: 110, valueGetter: (v, row) => formatDate(row.startDate) },
      { field: 'status', headerName: 'Status', width: 120, renderCell: (p) => <StatusChip status={p.value} /> },
    ],
    []
  );

  return (
    <>
      <PageHeader
        title="Bookings"
        subtitle="Every commercial request, from draft to confirmed."
        actions={
          <Button variant="contained" startIcon={<AddIcon />} onClick={() => navigate('/bookings/new')}>
            New Booking
          </Button>
        }
      />

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
          <TextField
            size="small"
            placeholder="Search Booking ID or customer"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ flex: 1, minWidth: 220 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
            }}
          />
          <TextField select size="small" label="Status" value={status} onChange={(e) => setStatus(e.target.value)} sx={{ width: 160 }}>
            <MenuItem value="All">All Statuses</MenuItem>
            <MenuItem value="Draft">Draft</MenuItem>
            <MenuItem value="Confirmed">Confirmed</MenuItem>
            <MenuItem value="Cancelled">Cancelled</MenuItem>
          </TextField>
        </Stack>
      </Paper>

      <Paper variant="outlined" sx={{ height: 560 }}>
        {isError ? (
          <ErrorState message={error.message} onRetry={refetch} />
        ) : !isLoading && (data?.length ?? 0) === 0 ? (
          <EmptyState
            title="No bookings yet"
            description="Create the first booking to start a subscription."
            actionLabel="New Booking"
            onAction={() => navigate('/bookings/new')}
          />
        ) : (
          <DataGrid
            rows={data || []}
            columns={columns}
            loading={isLoading}
            disableRowSelectionOnClick
            onRowClick={(p) => navigate(`/bookings/${p.row.bookingNumber}`)}
            sx={{ border: 'none', '& .MuiDataGrid-row': { cursor: 'pointer' } }}
            initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
            pageSizeOptions={[10, 25, 50]}
          />
        )}
      </Paper>
    </>
  );
}
