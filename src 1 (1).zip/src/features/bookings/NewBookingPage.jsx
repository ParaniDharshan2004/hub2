import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery } from '@tanstack/react-query';
import dayjs from 'dayjs';

import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Autocomplete from '@mui/material/Autocomplete';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Chip from '@mui/material/Chip';
import CircularProgress from '@mui/material/CircularProgress';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';

import PageHeader from '../../components/PageHeader';
import BillSummary from '../../components/BillSummary';
import { useSnackbar } from '../../components/SnackbarProvider';
import { listCustomers, listAddressesForCustomer } from '../../api/customers';
import { createDraftBooking, confirmBooking, quotePricing } from '../../api/bookings';
import {
  serviceAreas,
  serviceOfferings,
  frequencies,
  plans,
  paymentModes,
  serviceSlots,
} from '../../api/masters';

const schema = z.object({
  customer: z.any().refine((v) => !!v, 'Select a customer'),
  address: z.any().refine((v) => !!v, 'Select a service address'),
  offeringId: z.string().min(1, 'Select a service offering'),
  bathrooms: z.number({ invalid_type_error: 'Select number of bathrooms' }).min(1).max(4),
  frequencyId: z.string().min(1, 'Select a frequency'),
  planId: z.string().min(1, 'Select a plan'),
  discount: z.number().min(0).default(0),
  discountReason: z.string().optional().or(z.literal('')),
  startDate: z.any().refine((v) => !!v, 'Select a start date'),
  slotId: z.string().min(1, 'Select a service slot'),
  paymentModeId: z.string().min(1, 'Select a payment mode'),
  paymentReference: z.string().optional().or(z.literal('')),
});

const DISCOUNT_APPROVAL_THRESHOLD = 300;

const steps = ['Customer & Requirements', 'Schedule', 'Review & Confirm'];

export default function NewBookingPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const snackbar = useSnackbar();
  const [activeStep, setActiveStep] = useState(0);
  const [customerInput, setCustomerInput] = useState('');
  const [draftBookingNumber, setDraftBookingNumber] = useState(null);

  const {
    control,
    watch,
    trigger,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      customer: null,
      address: null,
      offeringId: '',
      bathrooms: '',
      frequencyId: '',
      planId: '',
      discount: 0,
      discountReason: '',
      startDate: dayjs().add(1, 'day'),
      slotId: '',
      paymentModeId: '',
      paymentReference: '',
    },
  });

  const values = watch();

  // Prefill from a "Create Booking" deep link (?customer=CUS-...&address=ADR-...)
  const { data: customerOptions = [], isFetching: loadingCustomers } = useQuery({
    queryKey: ['customer-options', customerInput],
    queryFn: () => listCustomers({ search: customerInput }),
    enabled: customerInput.length >= 2 || !!searchParams.get('customer'),
  });

  useEffect(() => {
    const prefillNumber = searchParams.get('customer');
    if (!prefillNumber) return;
    listCustomers({ search: prefillNumber }).then((rows) => {
      const match = rows.find((r) => r.customerNumber === prefillNumber);
      if (match) setValue('customer', match, { shouldValidate: true });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const { data: addressOptions = [] } = useQuery({
    queryKey: ['addresses-for-customer', values.customer?.id],
    queryFn: () => listAddressesForCustomer(values.customer.id),
    enabled: !!values.customer,
  });

  useEffect(() => {
    const prefillAddress = searchParams.get('address');
    if (!prefillAddress || addressOptions.length === 0) return;
    const match = addressOptions.find((a) => a.addressNumber === prefillAddress);
    if (match) setValue('address', match, { shouldValidate: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addressOptions]);

  const quote = useMemo(
    () =>
      quotePricing({
        planId: values.planId,
        frequencyId: values.frequencyId,
        bathrooms: values.bathrooms,
        discount: Number(values.discount) || 0,
      }),
    [values.planId, values.frequencyId, values.bathrooms, values.discount]
  );

  const requiresDiscountApproval = quote && quote.authorizedDiscount >= DISCOUNT_APPROVAL_THRESHOLD;

  const buildDraftPayload = () => ({
    customerId: values.customer.id,
    addressId: values.address.id,
    offeringId: values.offeringId,
    bathrooms: values.bathrooms,
    frequencyId: values.frequencyId,
    planId: values.planId,
    discount: Number(values.discount) || 0,
    discountReason: values.discountReason,
    startDate: values.startDate.format('YYYY-MM-DD'),
    slotId: values.slotId,
  });

  const draftMutation = useMutation({
    mutationFn: createDraftBooking,
    onSuccess: (booking) => {
      setDraftBookingNumber(booking.bookingNumber);
      snackbar.success(`Draft booking ${booking.bookingNumber} saved.`);
    },
    onError: (err) => snackbar.error(err.message),
  });

  const confirmMutation = useMutation({
    mutationFn: async () => {
      let bookingNumber = draftBookingNumber;
      if (!bookingNumber) {
        const draft = await createDraftBooking(buildDraftPayload());
        bookingNumber = draft.bookingNumber;
        setDraftBookingNumber(bookingNumber);
      }
      return confirmBooking(bookingNumber, {
        paymentModeId: values.paymentModeId,
        paymentReference: values.paymentReference,
      });
    },
    onSuccess: (result) => {
      snackbar.success(`Payment ${result.payment.paymentNumber} recorded successfully.`);
      snackbar.success(`Booking confirmed. Invoice ${result.invoice.invoiceNumber} is ready.`);
      navigate(`/bookings/${result.booking.bookingNumber}`);
    },
    onError: (err) => snackbar.error(err.message),
  });

  const handleNext = async () => {
    const stepFields = [
      ['customer', 'address', 'offeringId', 'bathrooms', 'frequencyId', 'planId'],
      ['startDate', 'slotId'],
    ][activeStep];
    const valid = await trigger(stepFields);
    if (!valid) return;
    setActiveStep((s) => s + 1);
  };

  const handleSaveDraft = async () => {
    const valid = await trigger(['customer', 'address', 'offeringId', 'bathrooms', 'frequencyId', 'planId', 'startDate', 'slotId']);
    if (!valid) return;
    draftMutation.mutate(buildDraftPayload());
  };

  const onConfirm = () => confirmMutation.mutate();

  return (
    <>
      <PageHeader
        title="New Booking"
        breadcrumbs={[{ label: 'Bookings', to: '/bookings' }, { label: 'New' }]}
      />

      <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 }, mb: 2 }}>
        <Stepper activeStep={activeStep} alternativeLabel>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Paper>

      <Grid container spacing={3}>
        <Grid item xs={12} md={7}>
          <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 } }}>
            {activeStep === 0 && (
              <Stack spacing={2.5}>
                <Typography variant="subtitle1">Customer & Requirements</Typography>

                <Controller
                  name="customer"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      options={customerOptions}
                      loading={loadingCustomers}
                      getOptionLabel={(o) => (o ? `${o.customerNumber} — ${o.name} (${o.mobile})` : '')}
                      isOptionEqualToValue={(o, v) => o.id === v.id}
                      value={field.value}
                      onChange={(_, v) => {
                        field.onChange(v);
                        setValue('address', null);
                      }}
                      onInputChange={(_, v) => setCustomerInput(v)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Customer"
                          required
                          error={!!errors.customer}
                          helperText={errors.customer?.message || 'Search by Customer ID, name, or mobile'}
                        />
                      )}
                    />
                  )}
                />

                <Controller
                  name="address"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      options={addressOptions}
                      disabled={!values.customer}
                      getOptionLabel={(o) =>
                        o ? `${o.addressNumber} — ${o.label}, ${serviceAreas.find((a) => a.id === o.area)?.name || ''}` : ''
                      }
                      isOptionEqualToValue={(o, v) => o.id === v.id}
                      value={field.value}
                      onChange={(_, v) => field.onChange(v)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Service Address"
                          required
                          error={!!errors.address}
                          helperText={errors.address?.message || (!values.customer ? 'Select a customer first' : ' ')}
                        />
                      )}
                    />
                  )}
                />

                <Stack direction="row" spacing={2}>
                  <Controller
                    name="offeringId"
                    control={control}
                    render={({ field }) => (
                      <TextField select label="Service Offering" required fullWidth {...field} error={!!errors.offeringId} helperText={errors.offeringId?.message}>
                        {serviceOfferings.map((o) => (
                          <MenuItem key={o.id} value={o.id}>
                            {o.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                  <Controller
                    name="bathrooms"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        select
                        label="No. of Bathrooms"
                        required
                        fullWidth
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                        error={!!errors.bathrooms}
                        helperText={errors.bathrooms?.message}
                      >
                        {[1, 2, 3, 4].map((n) => (
                          <MenuItem key={n} value={n}>
                            {n}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                </Stack>

                <Stack direction="row" spacing={2}>
                  <Controller
                    name="frequencyId"
                    control={control}
                    render={({ field }) => (
                      <TextField select label="Cleaning Frequency" required fullWidth {...field} error={!!errors.frequencyId} helperText={errors.frequencyId?.message}>
                        {frequencies.map((f) => (
                          <MenuItem key={f.id} value={f.id}>
                            {f.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                  <Controller
                    name="planId"
                    control={control}
                    render={({ field }) => (
                      <TextField select label="Subscription Plan" required fullWidth {...field} error={!!errors.planId} helperText={errors.planId?.message}>
                        {plans.map((p) => (
                          <MenuItem key={p.id} value={p.id}>
                            {p.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                </Stack>

                <Divider />
                <Stack direction="row" spacing={2}>
                  <Controller
                    name="discount"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        label="Optional Discount"
                        type="number"
                        fullWidth
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                      />
                    )}
                  />
                  <Controller
                    name="discountReason"
                    control={control}
                    render={({ field }) => <TextField label="Discount Reason" fullWidth {...field} disabled={!Number(values.discount)} />}
                  />
                </Stack>
                {requiresDiscountApproval && (
                  <Chip
                    size="small"
                    color="warning"
                    label="This discount exceeds the auto-approval threshold and requires a reason before confirmation."
                    sx={{ height: 'auto', py: 0.5, '& .MuiChip-label': { whiteSpace: 'normal' } }}
                  />
                )}
              </Stack>
            )}

            {activeStep === 1 && (
              <Stack spacing={2.5}>
                <Typography variant="subtitle1">Schedule</Typography>
                <Controller
                  name="startDate"
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      label="Service Start Date"
                      value={field.value}
                      onChange={field.onChange}
                      minDate={dayjs()}
                      slotProps={{ textField: { fullWidth: true, error: !!errors.startDate, helperText: errors.startDate?.message } }}
                    />
                  )}
                />
                <Controller
                  name="slotId"
                  control={control}
                  render={({ field }) => (
                    <TextField select label="Available Service Slot" required fullWidth {...field} error={!!errors.slotId} helperText={errors.slotId?.message}>
                      {serviceSlots.map((s) => (
                        <MenuItem key={s.id} value={s.id}>
                          {s.label}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
              </Stack>
            )}

            {activeStep === 2 && (
              <Stack spacing={2.5}>
                <Typography variant="subtitle1">Review & Confirm</Typography>
                <Stack spacing={0.5}>
                  <Typography variant="body2">
                    <strong>{values.customer?.name}</strong> · {values.customer?.customerNumber} · {values.customer?.mobile}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {values.address?.label}, {serviceAreas.find((a) => a.id === values.address?.area)?.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Start {values.startDate?.format('DD MMM YYYY')} · {serviceSlots.find((s) => s.id === values.slotId)?.label}
                  </Typography>
                </Stack>
                <Divider />
                <Controller
                  name="paymentModeId"
                  control={control}
                  render={({ field }) => (
                    <TextField select label="Payment Mode Received" required fullWidth {...field} error={!!errors.paymentModeId} helperText={errors.paymentModeId?.message}>
                      {paymentModes.map((m) => (
                        <MenuItem key={m.id} value={m.id}>
                          {m.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
                <Controller
                  name="paymentReference"
                  control={control}
                  render={({ field }) => <TextField label="Payment Reference (optional)" fullWidth {...field} />}
                />
                <Typography variant="caption" color="text.secondary">
                  Confirming will record the payment already collected, generate the invoice, activate the subscription, and
                  schedule all service visits in one step.
                </Typography>
              </Stack>
            )}

            <Stack direction="row" justifyContent="space-between" sx={{ mt: 4 }}>
              <Button disabled={activeStep === 0} onClick={() => setActiveStep((s) => s - 1)}>
                Back
              </Button>
              <Stack direction="row" spacing={1.5}>
                <Button
                  variant="text"
                  onClick={handleSaveDraft}
                  disabled={draftMutation.isPending}
                  startIcon={draftMutation.isPending ? <CircularProgress size={16} /> : null}
                >
                  Save Draft
                </Button>
                {activeStep < 2 ? (
                  <Button variant="contained" onClick={handleNext} disabled={!quote && activeStep === 0}>
                    Continue
                  </Button>
                ) : (
                  <Button
                    variant="contained"
                    onClick={handleSubmit(onConfirm)}
                    disabled={confirmMutation.isPending}
                    startIcon={confirmMutation.isPending ? <CircularProgress size={16} color="inherit" /> : null}
                  >
                    Confirm Booking
                  </Button>
                )}
              </Stack>
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12} md={5}>
          <BillSummary quote={quote} />
        </Grid>
      </Grid>
    </>
  );
}
