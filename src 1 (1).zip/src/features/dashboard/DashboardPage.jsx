import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import dayjs from 'dayjs';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import Chip from '@mui/material/Chip';
import ButtonBase from '@mui/material/ButtonBase';
import AddIcon from '@mui/icons-material/Add';
import EventNoteOutlinedIcon from '@mui/icons-material/EventNoteOutlined';
import CleaningServicesOutlinedIcon from '@mui/icons-material/CleaningServicesOutlined';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as ReTooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';

import PageHeader from '../../components/PageHeader';
import Money from '../../components/Money';
import EntityLink from '../../components/EntityLink';
import StatusChip from '../../components/StatusChip';
import { LoadingSkeleton, ErrorState } from '../../components/PageStates';
import { getDashboardSummary } from '../../api/dashboard';
import { serviceSlots } from '../../api/masters';
import { formatDate, formatDateTime } from '../../utils/format';

const CHART_COLORS = ['#0F5C57', '#3E9585', '#D98E04', '#C0392B', '#9FCDC3'];

function KpiCard({ label, value, onClick, accent }) {
  return (
    <ButtonBase onClick={onClick} sx={{ width: '100%', textAlign: 'left', borderRadius: 2 }}>
      <Paper variant="outlined" sx={{ p: 2, width: '100%' }}>
        <Typography variant="body2" color="text.secondary">
          {label}
        </Typography>
        <Typography variant="h2" sx={{ mt: 0.5, color: accent || 'text.primary' }}>
          {value}
        </Typography>
      </Paper>
    </ButtonBase>
  );
}

export default function DashboardPage() {
  const navigate = useNavigate();
  const today = dayjs().format('YYYY-MM-DD');

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['dashboard', today],
    queryFn: () => getDashboardSummary({ date: today }),
  });

  if (isLoading) {
    return (
      <>
        <PageHeader title="Dashboard" subtitle={dayjs().format('dddd, DD MMMM YYYY')} />
        <LoadingSkeleton rows={8} />
      </>
    );
  }
  if (isError) return <ErrorState message={error.message} onRetry={refetch} />;

  const { kpis, areaWorkload, collectionByMode, recentBookings, upcomingVisits, exceptions } = data;

  const visitPieData = [
    { name: 'Completed', value: kpis.completedToday },
    { name: 'Pending', value: kpis.pendingToday },
  ].filter((d) => d.value > 0);

  return (
    <>
      <PageHeader
        title="Dashboard"
        subtitle={dayjs().format('dddd, DD MMMM YYYY')}
        actions={
          <>
            <Button variant="outlined" startIcon={<AddIcon />} onClick={() => navigate('/customers')}>
              Add Customer
            </Button>
            <Button variant="contained" startIcon={<EventNoteOutlinedIcon />} onClick={() => navigate('/bookings/new')}>
              Create Booking
            </Button>
          </>
        }
      />

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6} sm={4} md={2.4}>
          <KpiCard label="Today's Visits" value={kpis.todayVisits} onClick={() => navigate('/visits/today')} />
        </Grid>
        <Grid item xs={6} sm={4} md={2.4}>
          <KpiCard label="Completed Today" value={kpis.completedToday} onClick={() => navigate('/visits/today?status=Completed')} />
        </Grid>
        <Grid item xs={6} sm={4} md={2.4}>
          <KpiCard label="Pending Today" value={kpis.pendingToday} onClick={() => navigate('/visits/today?status=Scheduled')} />
        </Grid>
        <Grid item xs={6} sm={4} md={2.4}>
          <KpiCard label="Rescheduled Today" value={kpis.rescheduledToday} onClick={() => navigate('/visits/today')} />
        </Grid>
        <Grid item xs={6} sm={4} md={2.4}>
          <KpiCard label="Active Subscriptions" value={kpis.activeSubscriptions} onClick={() => navigate('/subscriptions')} />
        </Grid>
      </Grid>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6} sm={3}>
          <KpiCard label="Renewals Due Soon" value={kpis.renewalsDueSoon} accent="warning.main" onClick={() => navigate('/subscriptions')} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <KpiCard label="Renewals Due" value={kpis.renewalsDue} accent="error.main" onClick={() => navigate('/subscriptions')} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Typography variant="body2" color="text.secondary">
              Today's Collection
            </Typography>
            <Typography variant="h2" sx={{ mt: 0.5 }}>
              <Money value={kpis.todaysCollection} strong />
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={6} sm={3}>
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Typography variant="body2" color="text.secondary">
              Month-to-Date Collection
            </Typography>
            <Typography variant="h2" sx={{ mt: 0.5 }}>
              <Money value={kpis.mtdCollection} strong />
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Paper variant="outlined" sx={{ p: 2.5, height: '100%' }}>
            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Today's Visit Status
            </Typography>
            {visitPieData.length === 0 ? (
              <Typography variant="body2" color="text.secondary">
                No visits scheduled today.
              </Typography>
            ) : (
              <Stack sx={{ height: 200 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={visitPieData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={2}>
                      {visitPieData.map((entry, i) => (
                        <Cell key={entry.name} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <ReTooltip />
                  </PieChart>
                </ResponsiveContainer>
              </Stack>
            )}
            <Stack direction="row" spacing={2} justifyContent="center" sx={{ mt: 1 }}>
              {visitPieData.map((d, i) => (
                <Stack key={d.name} direction="row" spacing={0.75} alignItems="center">
                  <Stack sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: CHART_COLORS[i % CHART_COLORS.length] }} />
                  <Typography variant="caption" color="text.secondary">
                    {d.name} ({d.value})
                  </Typography>
                </Stack>
              ))}
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12} md={8}>
          <Paper variant="outlined" sx={{ p: 2.5, height: '100%' }}>
            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Area-wise Workload Today
            </Typography>
            {areaWorkload.length === 0 ? (
              <Typography variant="body2" color="text.secondary">
                No visits scheduled today.
              </Typography>
            ) : (
              <Stack sx={{ height: 200 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={areaWorkload}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="areaName" fontSize={12} />
                    <YAxis allowDecimals={false} fontSize={12} />
                    <ReTooltip />
                    <Bar dataKey="completed" stackId="a" fill={CHART_COLORS[0]} name="Completed" />
                    <Bar dataKey="scheduled" stackId="a" fill={CHART_COLORS[2]} name="Scheduled" />
                  </BarChart>
                </ResponsiveContainer>
              </Stack>
            )}
          </Paper>
        </Grid>
      </Grid>

      <Grid container spacing={3} sx={{ mt: 0.5 }}>
        <Grid item xs={12} md={6}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.5 }}>
              <Typography variant="subtitle1">Upcoming Visits</Typography>
              <Button size="small" onClick={() => navigate('/visits')}>
                View All
              </Button>
            </Stack>
            {upcomingVisits.length === 0 ? (
              <Typography variant="body2" color="text.secondary">
                Nothing scheduled.
              </Typography>
            ) : (
              <Stack divider={<Divider />} spacing={1.25}>
                {upcomingVisits.map((v) => (
                  <Stack key={v.id} direction="row" justifyContent="space-between" alignItems="center">
                    <Stack direction="row" spacing={1.5} alignItems="center">
                      <CleaningServicesOutlinedIcon fontSize="small" color="action" />
                      <Stack>
                        <EntityLink type="Visit" id={v.visitNumber} />
                        <Typography variant="caption" color="text.secondary">
                          {v.customer?.name} · {formatDate(v.date)} ·{' '}
                          {serviceSlots.find((s) => s.id === v.slotId)?.label}
                        </Typography>
                      </Stack>
                    </Stack>
                    <StatusChip status={v.status} />
                  </Stack>
                ))}
              </Stack>
            )}
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.5 }}>
              <Typography variant="subtitle1">Recent Booking Confirmations</Typography>
              <Button size="small" onClick={() => navigate('/bookings')}>
                View All
              </Button>
            </Stack>
            {recentBookings.length === 0 ? (
              <Typography variant="body2" color="text.secondary">
                No confirmed bookings yet.
              </Typography>
            ) : (
              <Stack divider={<Divider />} spacing={1.25}>
                {recentBookings.map((b) => (
                  <Stack key={b.id} direction="row" justifyContent="space-between" alignItems="center">
                    <Stack>
                      <EntityLink type="Booking" id={b.bookingNumber} />
                      <Typography variant="caption" color="text.secondary">
                        {b.customer?.name} · {formatDateTime(b.confirmedOn)}
                      </Typography>
                    </Stack>
                    <Money value={b.total} />
                  </Stack>
                ))}
              </Stack>
            )}
          </Paper>
        </Grid>
      </Grid>

      {exceptions.staleDrafts.length > 0 && (
        <Paper variant="outlined" sx={{ p: 2.5, mt: 3, borderColor: 'warning.main' }}>
          <Typography variant="subtitle1" sx={{ mb: 1 }}>
            Exceptions
          </Typography>
          <Stack direction="row" spacing={1} flexWrap="wrap">
            {exceptions.staleDrafts.map((b) => (
              <Chip
                key={b.id}
                label={`Stale draft ${b.bookingNumber}`}
                color="warning"
                variant="outlined"
                onClick={() => navigate(`/bookings/${b.bookingNumber}`)}
              />
            ))}
          </Stack>
        </Paper>
      )}
    </>
  );
}
