import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import InputAdornment from '@mui/material/InputAdornment';
import { DataGrid } from '@mui/x-data-grid';
import SearchIcon from '@mui/icons-material/Search';

import PageHeader from '../../components/PageHeader';
import EntityLink from '../../components/EntityLink';
import StatusChip from '../../components/StatusChip';
import Money from '../../components/Money';
import { EmptyState, ErrorState } from '../../components/PageStates';
import { listPayments } from '../../api/payments';
import { paymentModes } from '../../api/masters';
import { formatDate } from '../../utils/format';

export default function PaymentListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [modeId, setModeId] = useState('All');

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['payments', search, status, modeId],
    queryFn: () => listPayments({ search, status, modeId }),
  });

  const rows = data || [];
  const totalCollected = rows.filter((p) => p.status !== 'Reversed').reduce((s, p) => s + p.amount, 0);

  const columns = useMemo(
    () => [
      { field: 'paymentNumber', headerName: 'Payment ID', width: 190, renderCell: (p) => <EntityLink type="Payment" id={p.value} /> },
      {
        field: 'customer',
        headerName: 'Customer',
        flex: 1,
        minWidth: 160,
        valueGetter: (v, row) => (row.customer ? `${row.customer.name} (${row.customer.customerNumber})` : '—'),
      },
      { field: 'booking', headerName: 'Booking ID', width: 190, renderCell: (p) => (p.row.booking ? <EntityLink type="Booking" id={p.row.booking.bookingNumber} /> : '—') },
      { field: 'invoice', headerName: 'Invoice', width: 170, renderCell: (p) => (p.row.invoice ? <EntityLink type="Invoice" id={p.row.invoice.invoiceNumber} /> : '—') },
      { field: 'amount', headerName: 'Amount', width: 130, renderCell: (p) => <Money value={p.value} /> },
      { field: 'modeId', headerName: 'Mode', width: 120, valueGetter: (v, row) => paymentModes.find((m) => m.id === row.modeId)?.name || '—' },
      { field: 'paymentDate', headerName: 'Payment Date', width: 130, valueGetter: (v, row) => formatDate(row.paymentDate) },
      { field: 'status', headerName: 'Status', width: 120, renderCell: (p) => <StatusChip status={p.value} /> },
    ],
    []
  );

  return (
    <>
      <PageHeader title="Payments" subtitle="Every payment already collected and recorded against a confirmed booking." />

      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12} sm={4}>
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Typography variant="body2" color="text.secondary">
              Total Collected (filtered)
            </Typography>
            <Typography variant="h2" sx={{ mt: 0.5 }}>
              <Money value={totalCollected} strong />
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
          <TextField
            size="small"
            placeholder="Search Payment ID, customer, or Booking ID"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ flex: 1, minWidth: 220 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
            }}
          />
          <TextField select size="small" label="Mode" value={modeId} onChange={(e) => setModeId(e.target.value)} sx={{ width: 160 }}>
            <MenuItem value="All">All Modes</MenuItem>
            {paymentModes.map((m) => (
              <MenuItem key={m.id} value={m.id}>
                {m.name}
              </MenuItem>
            ))}
          </TextField>
          <TextField select size="small" label="Status" value={status} onChange={(e) => setStatus(e.target.value)} sx={{ width: 160 }}>
            <MenuItem value="All">All Statuses</MenuItem>
            <MenuItem value="Recorded">Recorded</MenuItem>
            <MenuItem value="Reversed">Reversed</MenuItem>
          </TextField>
        </Stack>
      </Paper>

      <Paper variant="outlined" sx={{ height: 560 }}>
        {isError ? (
          <ErrorState message={error.message} onRetry={refetch} />
        ) : !isLoading && rows.length === 0 ? (
          <EmptyState title="No payments yet" description="Payments are recorded automatically when a booking is confirmed." />
        ) : (
          <DataGrid
            rows={rows}
            columns={columns}
            loading={isLoading}
            disableRowSelectionOnClick
            onRowClick={(p) => navigate(`/payments/${p.row.paymentNumber}`)}
            sx={{ border: 'none', '& .MuiDataGrid-row': { cursor: 'pointer' } }}
            initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
            pageSizeOptions={[10, 25, 50]}
          />
        )}
      </Paper>
    </>
  );
}
