import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import LinearProgress from '@mui/material/LinearProgress';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableBody from '@mui/material/TableBody';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Chip from '@mui/material/Chip';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import AutorenewIcon from '@mui/icons-material/Autorenew';

import PageHeader from '../../components/PageHeader';
import StatusChip from '../../components/StatusChip';
import EntityLink from '../../components/EntityLink';
import { LoadingSkeleton, ErrorState } from '../../components/PageStates';
import { getSubscription } from '../../api/subscriptions';
import { serviceAreas, plans, frequencies, serviceOfferings, serviceSlots } from '../../api/masters';
import { formatDate } from '../../utils/format';
import RenewSubscriptionDialog from './RenewSubscriptionDialog';

export default function SubscriptionDetailPage({ renewMode = false }) {
  const { subscriptionNumber } = useParams();
  const navigate = useNavigate();
  const [renewOpen, setRenewOpen] = useState(renewMode);

  const { data: subscription, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['subscription', subscriptionNumber],
    queryFn: () => getSubscription(subscriptionNumber),
  });

  useEffect(() => {
    if (renewMode) setRenewOpen(true);
  }, [renewMode]);

  if (isLoading) {
    return (
      <>
        <PageHeader
          title="Loading subscription…"
          breadcrumbs={[{ label: 'Subscriptions', to: '/subscriptions' }, { label: subscriptionNumber }]}
        />
        <LoadingSkeleton rows={8} />
      </>
    );
  }
  if (isError) return <ErrorState message={error.message} onRetry={refetch} />;
  if (!subscription) return <ErrorState message={`Subscription ${subscriptionNumber} was not found.`} />;

  const { customer, address, currentPeriod, periods } = subscription;

  return (
    <>
      <PageHeader
        title={subscription.subscriptionNumber}
        breadcrumbs={[{ label: 'Subscriptions', to: '/subscriptions' }, { label: subscription.subscriptionNumber }]}
        statusSlot={<StatusChip status={subscription.status} />}
        actions={
          <Button variant="contained" startIcon={<AutorenewIcon />} onClick={() => setRenewOpen(true)}>
            Renew
          </Button>
        }
      />

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 }, mb: 3 }}>
            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Customer & Address
            </Typography>
            <Stack spacing={0.5}>
              <Stack direction="row" spacing={1} alignItems="center">
                <EntityLink type="Customer" id={customer?.customerNumber} />
              </Stack>
              <Typography variant="body2">{customer?.name}</Typography>
              <Typography variant="body2" color="text.secondary">
                {customer?.mobile}
              </Typography>
              <Divider sx={{ my: 1 }} />
              <Typography variant="body2">{address?.label}</Typography>
              <Typography variant="body2" color="text.secondary">
                {address?.addressLine}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {serviceAreas.find((a) => a.id === address?.area)?.name}, {address?.city} {address?.pincode}
              </Typography>
            </Stack>

            <Divider sx={{ my: 2 }} />
            <Typography variant="body2" color="text.secondary">
              Service Offering
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              {serviceOfferings.find((o) => o.id === subscription.offeringId)?.name}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Renewal Status
            </Typography>
            <StatusChip status={subscription.renewalStatus} />
          </Paper>

          {currentPeriod && (
            <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 } }}>
              <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
                Current Period
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {plans.find((p) => p.id === currentPeriod.planId)?.name} ·{' '}
                {frequencies.find((f) => f.id === currentPeriod.frequencyId)?.name}
              </Typography>
              <Stack direction="row" justifyContent="space-between" sx={{ mt: 1.5, mb: 0.5 }}>
                <Typography variant="caption" color="text.secondary">
                  {currentPeriod.completedServices}/{currentPeriod.totalServices} services
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Ends {formatDate(currentPeriod.endDate)}
                </Typography>
              </Stack>
              <LinearProgress
                variant="determinate"
                value={Math.round((currentPeriod.completedServices / currentPeriod.totalServices) * 100)}
                sx={{ height: 6, borderRadius: 3 }}
              />
            </Paper>
          )}
        </Grid>

        <Grid item xs={12} md={8}>
          <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
            Subscription Periods
          </Typography>
          <Stack spacing={2}>
            {periods.map((period, idx) => (
              <Accordion key={period.id} defaultExpanded={idx === 0} variant="outlined" disableGutters>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Stack direction="row" spacing={1.5} alignItems="center" sx={{ width: '100%', pr: 2 }}>
                    <EntityLink type="Period" id={period.periodNumber} />
                    <Chip size="small" label={period.kind} variant="outlined" />
                    <StatusChip status={period.status} />
                    <Stack sx={{ flex: 1 }} />
                    <Typography variant="caption" color="text.secondary">
                      {formatDate(period.startDate)} – {formatDate(period.endDate)}
                    </Typography>
                  </Stack>
                </AccordionSummary>
                <AccordionDetails>
                  <Grid container spacing={2} sx={{ mb: 2 }}>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="caption" color="text.secondary">
                        Plan
                      </Typography>
                      <Typography variant="body2">{plans.find((p) => p.id === period.planId)?.name}</Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="caption" color="text.secondary">
                        Frequency
                      </Typography>
                      <Typography variant="body2">{frequencies.find((f) => f.id === period.frequencyId)?.name}</Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="caption" color="text.secondary">
                        Services
                      </Typography>
                      <Typography variant="body2">
                        {period.completedServices}/{period.totalServices}
                      </Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="caption" color="text.secondary">
                        Source Booking
                      </Typography>
                      <Typography variant="body2">
                        {period.booking ? <EntityLink type="Booking" id={period.booking.bookingNumber} /> : '—'}
                      </Typography>
                    </Grid>
                  </Grid>

                  <Typography variant="body2" sx={{ mb: 1, fontWeight: 600 }}>
                    Service Visits
                  </Typography>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Visit ID</TableCell>
                        <TableCell>Date</TableCell>
                        <TableCell>Slot</TableCell>
                        <TableCell>Status</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {period.visits.map((v) => (
                        <TableRow key={v.id} hover>
                          <TableCell>
                            <EntityLink type="Visit" id={v.visitNumber} />
                          </TableCell>
                          <TableCell>{formatDate(v.date)}</TableCell>
                          <TableCell>{serviceSlots.find((s) => s.id === v.slotId)?.label}</TableCell>
                          <TableCell>
                            <StatusChip status={v.status} />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </AccordionDetails>
              </Accordion>
            ))}
          </Stack>
        </Grid>
      </Grid>

      <RenewSubscriptionDialog
        open={renewOpen}
        onClose={() => {
          setRenewOpen(false);
          if (renewMode) navigate(`/subscriptions/${subscriptionNumber}`, { replace: true });
        }}
        subscription={subscription}
        onRenewed={() => {
          setRenewOpen(false);
          refetch();
          if (renewMode) navigate(`/subscriptions/${subscriptionNumber}`, { replace: true });
        }}
      />
    </>
  );
}
