import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import InputAdornment from '@mui/material/InputAdornment';
import LinearProgress from '@mui/material/LinearProgress';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { DataGrid } from '@mui/x-data-grid';
import SearchIcon from '@mui/icons-material/Search';

import PageHeader from '../../components/PageHeader';
import EntityLink from '../../components/EntityLink';
import StatusChip from '../../components/StatusChip';
import { EmptyState, ErrorState } from '../../components/PageStates';
import { listSubscriptions } from '../../api/subscriptions';
import { serviceAreas, plans, serviceOfferings } from '../../api/masters';
import { formatDate } from '../../utils/format';

export default function SubscriptionListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['subscriptions', search, status],
    queryFn: () => listSubscriptions({ search, status }),
  });

  const columns = useMemo(
    () => [
      {
        field: 'subscriptionNumber',
        headerName: 'Subscription ID',
        width: 170,
        renderCell: (p) => <EntityLink type="Subscription" id={p.value} />,
      },
      {
        field: 'customer',
        headerName: 'Customer',
        flex: 1,
        minWidth: 160,
        valueGetter: (v, row) => (row.customer ? `${row.customer.name} (${row.customer.customerNumber})` : '—'),
      },
      {
        field: 'address',
        headerName: 'Address / Area',
        width: 170,
        valueGetter: (v, row) =>
          row.address ? `${row.address.label}, ${serviceAreas.find((a) => a.id === row.address.area)?.name || ''}` : '—',
      },
      {
        field: 'offeringId',
        headerName: 'Offering',
        width: 160,
        valueGetter: (v, row) => serviceOfferings.find((o) => o.id === row.offeringId)?.name || '—',
      },
      {
        field: 'plan',
        headerName: 'Current Plan',
        width: 150,
        valueGetter: (v, row) => (row.currentPeriod ? plans.find((p) => p.id === row.currentPeriod.planId)?.name : '—'),
      },
      {
        field: 'progress',
        headerName: 'Services',
        width: 150,
        sortable: false,
        renderCell: (params) => {
          const period = params.row.currentPeriod;
          if (!period) return '—';
          const pct = Math.round((period.completedServices / period.totalServices) * 100);
          return (
            <Box sx={{ width: '100%' }}>
              <Typography variant="caption" color="text.secondary">
                {period.completedServices}/{period.totalServices}
              </Typography>
              <LinearProgress variant="determinate" value={pct} sx={{ height: 5, borderRadius: 3 }} />
            </Box>
          );
        },
      },
      {
        field: 'endDate',
        headerName: 'Period End',
        width: 120,
        valueGetter: (v, row) => (row.currentPeriod ? formatDate(row.currentPeriod.endDate) : '—'),
      },
      {
        field: 'nextVisit',
        headerName: 'Next Visit',
        width: 120,
        valueGetter: (v, row) => (row.nextVisit ? formatDate(row.nextVisit.date) : '—'),
      },
      { field: 'status', headerName: 'Status', width: 110, renderCell: (p) => <StatusChip status={p.value} /> },
      {
        field: 'renewalStatus',
        headerName: 'Renewal',
        width: 150,
        renderCell: (p) => <StatusChip status={p.value} />,
      },
    ],
    []
  );

  return (
    <>
      <PageHeader
        title="Subscriptions"
        subtitle="The continuing relationship for each customer, address, and service offering."
      />

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
          <TextField
            size="small"
            placeholder="Search Subscription ID or customer"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ flex: 1, minWidth: 220 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
            }}
          />
          <TextField select size="small" label="Status" value={status} onChange={(e) => setStatus(e.target.value)} sx={{ width: 160 }}>
            <MenuItem value="All">All Statuses</MenuItem>
            <MenuItem value="Active">Active</MenuItem>
            <MenuItem value="Inactive">Inactive</MenuItem>
          </TextField>
        </Stack>
      </Paper>

      <Paper variant="outlined" sx={{ height: 560 }}>
        {isError ? (
          <ErrorState message={error.message} onRetry={refetch} />
        ) : !isLoading && (data?.length ?? 0) === 0 ? (
          <EmptyState
            title="No subscriptions yet"
            description="Subscriptions are created automatically once a booking is confirmed."
          />
        ) : (
          <DataGrid
            rows={data || []}
            columns={columns}
            loading={isLoading}
            disableRowSelectionOnClick
            onRowClick={(p) => navigate(`/subscriptions/${p.row.subscriptionNumber}`)}
            sx={{ border: 'none', '& .MuiDataGrid-row': { cursor: 'pointer' } }}
            initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
            pageSizeOptions={[10, 25, 50]}
            getRowHeight={() => 56}
          />
        )}
      </Paper>
    </>
  );
}
