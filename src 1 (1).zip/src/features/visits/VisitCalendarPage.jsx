import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import dayjs from 'dayjs';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Button from '@mui/material/Button';
import Chip from '@mui/material/Chip';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import TodayIcon from '@mui/icons-material/Today';

import PageHeader from '../../components/PageHeader';
import { LoadingSkeleton, ErrorState } from '../../components/PageStates';
import { listVisits } from '../../api/visits';

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function VisitCalendarPage() {
  const navigate = useNavigate();
  const [cursor, setCursor] = useState(dayjs().startOf('month'));

  const monthStart = cursor.startOf('month');
  const monthEnd = cursor.endOf('month');
  const gridStart = monthStart.startOf('week');
  const gridEnd = monthEnd.endOf('week');

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['visits', 'calendar', monthStart.format('YYYY-MM')],
    queryFn: () => listVisits({ dateFrom: gridStart.format('YYYY-MM-DD'), dateTo: gridEnd.format('YYYY-MM-DD') }),
  });

  const days = useMemo(() => {
    const arr = [];
    let d = gridStart;
    while (d.isBefore(gridEnd) || d.isSame(gridEnd, 'day')) {
      arr.push(d);
      d = d.add(1, 'day');
    }
    return arr;
  }, [gridStart, gridEnd]);

  const visitsByDay = useMemo(() => {
    const map = {};
    (data || []).forEach((v) => {
      const key = dayjs(v.date).format('YYYY-MM-DD');
      map[key] = map[key] || { total: 0, completed: 0 };
      map[key].total += 1;
      if (v.status === 'Completed') map[key].completed += 1;
    });
    return map;
  }, [data]);

  if (isError) return <ErrorState message={error.message} onRetry={refetch} />;

  return (
    <>
      <PageHeader
        title="Visits Calendar"
        actions={
          <>
            <Button size="small" startIcon={<TodayIcon />} onClick={() => setCursor(dayjs().startOf('month'))}>
              Today
            </Button>
            <IconButton size="small" onClick={() => setCursor((c) => c.subtract(1, 'month'))} aria-label="Previous month">
              <ChevronLeftIcon />
            </IconButton>
            <Typography sx={{ minWidth: 130, textAlign: 'center', pt: 0.5 }}>{cursor.format('MMMM YYYY')}</Typography>
            <IconButton size="small" onClick={() => setCursor((c) => c.add(1, 'month'))} aria-label="Next month">
              <ChevronRightIcon />
            </IconButton>
          </>
        }
      />

      {isLoading ? (
        <LoadingSkeleton rows={6} />
      ) : (
        <Paper variant="outlined" sx={{ overflow: 'hidden' }}>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', bgcolor: 'background.default' }}>
            {WEEKDAYS.map((w) => (
              <Box key={w} sx={{ p: 1, textAlign: 'center', borderBottom: '1px solid', borderColor: 'divider' }}>
                <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>
                  {w}
                </Typography>
              </Box>
            ))}
          </Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)' }}>
            {days.map((d) => {
              const key = d.format('YYYY-MM-DD');
              const info = visitsByDay[key];
              const inMonth = d.isSame(monthStart, 'month');
              const isToday = d.isSame(dayjs(), 'day');
              return (
                <Box
                  key={key}
                  onClick={() => navigate(`/visits/day/${key}`)}
                  sx={{
                    minHeight: 90,
                    p: 1,
                    borderRight: '1px solid',
                    borderBottom: '1px solid',
                    borderColor: 'divider',
                    opacity: inMonth ? 1 : 0.4,
                    cursor: 'pointer',
                    bgcolor: isToday ? 'teal.50' : 'transparent',
                    '&:hover': { bgcolor: 'background.default' },
                  }}
                >
                  <Typography variant="caption" sx={{ fontWeight: isToday ? 700 : 500 }}>
                    {d.format('D')}
                  </Typography>
                  {info && (
                    <Stack spacing={0.5} sx={{ mt: 0.5 }}>
                      <Chip
                        size="small"
                        label={`${info.total} visit${info.total === 1 ? '' : 's'}`}
                        color={info.completed === info.total ? 'success' : 'info'}
                        variant="outlined"
                        sx={{ fontSize: '0.65rem', height: 20 }}
                      />
                    </Stack>
                  )}
                </Box>
              );
            })}
          </Box>
        </Paper>
      )}
    </>
  );
}
