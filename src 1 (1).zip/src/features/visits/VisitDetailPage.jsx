import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Alert from '@mui/material/Alert';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import EventRepeatIcon from '@mui/icons-material/EventRepeat';

import PageHeader from '../../components/PageHeader';
import StatusChip from '../../components/StatusChip';
import EntityLink from '../../components/EntityLink';
import { LoadingSkeleton, ErrorState } from '../../components/PageStates';
import { getVisit } from '../../api/visits';
import { serviceAreas, serviceSlots, plans } from '../../api/masters';
import { formatDate, formatDateTime } from '../../utils/format';
import CompleteVisitDialog from './CompleteVisitDialog';
import RescheduleVisitDialog from './RescheduleVisitDialog';

export default function VisitDetailPage() {
  const { visitNumber } = useParams();
  const [completeOpen, setCompleteOpen] = useState(false);
  const [rescheduleOpen, setRescheduleOpen] = useState(false);

  const { data: visit, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['visit', visitNumber],
    queryFn: () => getVisit(visitNumber),
  });

  if (isLoading) {
    return (
      <>
        <PageHeader title="Loading visit…" breadcrumbs={[{ label: 'Visits', to: '/visits' }, { label: visitNumber }]} />
        <LoadingSkeleton rows={8} />
      </>
    );
  }
  if (isError) return <ErrorState message={error.message} onRetry={refetch} />;
  if (!visit) return <ErrorState message={`Visit ${visitNumber} was not found.`} />;

  const canComplete = visit.status !== 'Completed' && visit.status !== 'Cancelled';
  const canReschedule = visit.status !== 'Completed';
  const addressChanged = visit.address && visit.address.updatedOn && visit.address.updatedOn > visit.date;

  return (
    <>
      <PageHeader
        title={visit.visitNumber}
        breadcrumbs={[{ label: 'Visits', to: '/visits' }, { label: visit.visitNumber }]}
        statusSlot={<StatusChip status={visit.status} />}
        actions={
          <>
            {canReschedule && (
              <Button variant="outlined" startIcon={<EventRepeatIcon />} onClick={() => setRescheduleOpen(true)}>
                Reschedule
              </Button>
            )}
            {canComplete && (
              <Button variant="contained" startIcon={<CheckCircleOutlineIcon />} onClick={() => setCompleteOpen(true)}>
                Complete
              </Button>
            )}
          </>
        }
      />

      <Grid container spacing={3}>
        <Grid item xs={12} md={7}>
          <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 }, mb: 3 }}>
            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Customer & Address
            </Typography>
            <Stack spacing={0.5}>
              <Stack direction="row" spacing={1} alignItems="center">
                <EntityLink type="Customer" id={visit.customer?.customerNumber} />
                <Typography variant="body2">{visit.customer?.name}</Typography>
              </Stack>
              <Typography variant="body2" color="text.secondary">
                {[visit.address?.doorNo, visit.address?.block, visit.address?.addressLine].filter(Boolean).join(', ')}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {serviceAreas.find((a) => a.id === visit.areaId)?.name}, {visit.address?.city} {visit.address?.pincode}
              </Typography>
            </Stack>

            {addressChanged && (
              <Alert severity="warning" sx={{ mt: 2 }}>
                The live address has been updated since this visit was scheduled. The details above are the snapshot at
                scheduling time.
              </Alert>
            )}

            <Divider sx={{ my: 2 }} />

            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Schedule
            </Typography>
            <Grid container spacing={1.5}>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Scheduled Date
                </Typography>
                <Typography variant="body2">{formatDate(visit.date)}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Slot
                </Typography>
                <Typography variant="body2">{serviceSlots.find((s) => s.id === visit.slotId)?.label}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Sequence
                </Typography>
                <Typography variant="body2">{visit.sequence}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Plan
                </Typography>
                <Typography variant="body2">{plans.find((p) => p.id === visit.period?.planId)?.name || '—'}</Typography>
              </Grid>
            </Grid>

            {visit.status === 'Completed' && (
              <>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
                  Completion Details
                </Typography>
                <Grid container spacing={1.5}>
                  <Grid item xs={6}>
                    <Typography variant="caption" color="text.secondary">
                      Completed On
                    </Typography>
                    <Typography variant="body2">{formatDateTime(visit.completedOn)}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="caption" color="text.secondary">
                      Completed By
                    </Typography>
                    <Typography variant="body2">{visit.completedBy}</Typography>
                  </Grid>
                  {visit.completionRemarks && (
                    <Grid item xs={12}>
                      <Typography variant="caption" color="text.secondary">
                        Remarks
                      </Typography>
                      <Typography variant="body2">{visit.completionRemarks}</Typography>
                    </Grid>
                  )}
                </Grid>
              </>
            )}

            {visit.rescheduleHistory?.length > 0 && (
              <>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
                  Reschedule History
                </Typography>
                <List dense disablePadding>
                  {visit.rescheduleHistory.map((h, i) => (
                    <ListItem key={i} disableGutters>
                      <ListItemText
                        primary={`${formatDate(h.fromDate)} → ${formatDate(h.toDate)}`}
                        secondary={`${h.reason}${h.remarks ? ` — ${h.remarks}` : ''} · ${formatDateTime(h.changedOn)}`}
                      />
                    </ListItem>
                  ))}
                </List>
              </>
            )}
          </Paper>
        </Grid>

        <Grid item xs={12} md={5}>
          <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 } }}>
            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Related Records
            </Typography>
            <List dense disablePadding>
              <ListItem disableGutters>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 110 }}>
                        Subscription
                      </Typography>
                      {visit.subscription ? <EntityLink type="Subscription" id={visit.subscription.subscriptionNumber} /> : '—'}
                    </Stack>
                  }
                />
              </ListItem>
              <ListItem disableGutters>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 110 }}>
                        Period
                      </Typography>
                      {visit.period ? <EntityLink type="Period" id={visit.period.periodNumber} /> : '—'}
                    </Stack>
                  }
                />
              </ListItem>
              <ListItem disableGutters>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 110 }}>
                        Source Booking
                      </Typography>
                      {visit.booking ? <EntityLink type="Booking" id={visit.booking.bookingNumber} /> : '—'}
                    </Stack>
                  }
                />
              </ListItem>
            </List>
          </Paper>
        </Grid>
      </Grid>

      <CompleteVisitDialog open={completeOpen} onClose={() => setCompleteOpen(false)} visitNumbers={[visit.visitNumber]} />
      <RescheduleVisitDialog open={rescheduleOpen} onClose={() => setRescheduleOpen(false)} visit={visit} />
    </>
  );
}
