import { useMemo, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import dayjs from 'dayjs';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import InputAdornment from '@mui/material/InputAdornment';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import Chip from '@mui/material/Chip';
import { DataGrid } from '@mui/x-data-grid';
import SearchIcon from '@mui/icons-material/Search';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import DownloadOutlinedIcon from '@mui/icons-material/DownloadOutlined';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';

import PageHeader from '../../components/PageHeader';
import EntityLink from '../../components/EntityLink';
import StatusChip from '../../components/StatusChip';
import { EmptyState, ErrorState } from '../../components/PageStates';
import { useSnackbar } from '../../components/SnackbarProvider';
import { listVisits } from '../../api/visits';
import { serviceAreas, serviceSlots } from '../../api/masters';
import { formatDate } from '../../utils/format';
import CompleteVisitDialog from './CompleteVisitDialog';
import RescheduleVisitDialog from './RescheduleVisitDialog';

function RowActions({ row, onComplete, onReschedule }) {
  const navigate = useNavigate();
  const [anchor, setAnchor] = useState(null);
  const snackbar = useSnackbar();

  const copyAddress = () => {
    const text = [row.address?.doorNo, row.address?.block, row.address?.addressLine].filter(Boolean).join(', ');
    navigator.clipboard?.writeText(text);
    snackbar.info('Address copied to clipboard.');
    setAnchor(null);
  };

  return (
    <>
      <IconButton size="small" onClick={(e) => setAnchor(e.currentTarget)} aria-label="Row actions">
        <MoreVertIcon fontSize="small" />
      </IconButton>
      <Menu anchorEl={anchor} open={!!anchor} onClose={() => setAnchor(null)}>
        <MenuItem onClick={() => navigate(`/visits/${row.visitNumber}`)}>View Visit</MenuItem>
        {row.status !== 'Completed' && row.status !== 'Cancelled' && (
          <MenuItem
            onClick={() => {
              onComplete([row.visitNumber]);
              setAnchor(null);
            }}
          >
            Complete
          </MenuItem>
        )}
        {row.status !== 'Completed' && (
          <MenuItem
            onClick={() => {
              onReschedule(row);
              setAnchor(null);
            }}
          >
            Reschedule
          </MenuItem>
        )}
        <MenuItem onClick={() => navigate(`/customers/${row.customer?.customerNumber}`)}>Open Customer</MenuItem>
        <MenuItem onClick={copyAddress}>Copy Address</MenuItem>
      </Menu>
    </>
  );
}

export default function VisitListPage({ mode = 'all' }) {
  const navigate = useNavigate();
  const snackbar = useSnackbar();
  const { date: routeDate, areaCode } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();

  const [search, setSearch] = useState('');
  const [selection, setSelection] = useState([]);
  const [completeTarget, setCompleteTarget] = useState(null);
  const [rescheduleTarget, setRescheduleTarget] = useState(null);

  const status = searchParams.get('status') || 'All';
  const areaFilter = mode === 'area' ? areaCode : searchParams.get('area') || 'All';
  const fixedDate = mode === 'today' ? dayjs().format('YYYY-MM-DD') : mode === 'day' ? routeDate : null;

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['visits', mode, fixedDate, areaFilter, status, search],
    queryFn: () => listVisits({ search, status, area: areaFilter, date: fixedDate }),
  });

  const setStatus = (value) => setSearchParams((prev) => {
    const next = new URLSearchParams(prev);
    if (value === 'All') next.delete('status');
    else next.set('status', value);
    return next;
  });
  const setArea = (value) => setSearchParams((prev) => {
    const next = new URLSearchParams(prev);
    if (value === 'All') next.delete('area');
    else next.set('area', value);
    return next;
  });

  const columns = useMemo(
    () => [
      { field: 'visitNumber', headerName: 'Visit ID', width: 160, renderCell: (p) => <EntityLink type="Visit" id={p.value} /> },
      { field: 'sequence', headerName: 'Seq', width: 70, type: 'number' },
      { field: 'date', headerName: 'Date', width: 120, valueGetter: (v, row) => formatDate(row.date) },
      { field: 'slotId', headerName: 'Slot', width: 160, valueGetter: (v, row) => serviceSlots.find((s) => s.id === row.slotId)?.label || '—' },
      {
        field: 'customer',
        headerName: 'Customer',
        flex: 1,
        minWidth: 160,
        valueGetter: (v, row) => (row.customer ? `${row.customer.name} (${row.customer.customerNumber})` : '—'),
      },
      {
        field: 'address',
        headerName: 'Area',
        width: 130,
        valueGetter: (v, row) => serviceAreas.find((a) => a.id === row.areaId)?.name || '—',
      },
      {
        field: 'subscription',
        headerName: 'Subscription',
        width: 150,
        renderCell: (p) => (p.row.subscription ? <EntityLink type="Subscription" id={p.row.subscription.subscriptionNumber} /> : '—'),
      },
      { field: 'status', headerName: 'Status', width: 130, renderCell: (p) => <StatusChip status={p.value} /> },
      {
        field: 'actions',
        headerName: '',
        width: 60,
        sortable: false,
        filterable: false,
        disableColumnMenu: true,
        renderCell: (p) => (
          <RowActions row={p.row} onComplete={setCompleteTarget} onReschedule={setRescheduleTarget} />
        ),
      },
    ],
    []
  );

  const rows = data || [];
  const kpis = useMemo(() => {
    if (mode !== 'today') return null;
    return {
      total: rows.length,
      scheduled: rows.filter((v) => v.status === 'Scheduled').length,
      completed: rows.filter((v) => v.status === 'Completed').length,
      rescheduled: rows.filter((v) => (v.rescheduleHistory || []).length > 0).length,
      areas: new Set(rows.map((v) => v.areaId)).size,
    };
  }, [rows, mode]);

  const title = mode === 'today' ? "Today's Visits" : mode === 'day' ? `Visits — ${formatDate(routeDate)}` : mode === 'area' ? `Visits — ${serviceAreas.find((a) => a.id === areaCode)?.name || areaCode}` : 'Visits';

  const eligibleForBatch = rows.filter((r) => selection.includes(r.id) && r.status !== 'Completed' && r.status !== 'Cancelled').map((r) => r.visitNumber);

  return (
    <>
      <PageHeader
        title={title}
        subtitle="Every scheduled cleaning occurrence, generated from confirmed subscription periods."
        actions={
          <>
            <Button
              variant="outlined"
              startIcon={<DownloadOutlinedIcon />}
              onClick={() => snackbar.info('Worksheet PDF generation is part of the next phase.')}
            >
              Download Worksheet
            </Button>
            {eligibleForBatch.length > 0 && (
              <Button variant="contained" startIcon={<CheckCircleOutlineIcon />} onClick={() => setCompleteTarget(eligibleForBatch)}>
                Complete Selected ({eligibleForBatch.length})
              </Button>
            )}
          </>
        }
      />

      {kpis && (
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={6} sm={2.4}>
            <Paper variant="outlined" sx={{ p: 1.5, textAlign: 'center' }}>
              <Typography variant="h3">{kpis.total}</Typography>
              <Typography variant="caption" color="text.secondary">
                Total
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6} sm={2.4}>
            <Paper variant="outlined" sx={{ p: 1.5, textAlign: 'center' }}>
              <Typography variant="h3" color="success.main">
                {kpis.completed}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Completed
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6} sm={2.4}>
            <Paper variant="outlined" sx={{ p: 1.5, textAlign: 'center' }}>
              <Typography variant="h3" color="info.main">
                {kpis.scheduled}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Scheduled
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6} sm={2.4}>
            <Paper variant="outlined" sx={{ p: 1.5, textAlign: 'center' }}>
              <Typography variant="h3" color="warning.main">
                {kpis.rescheduled}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Rescheduled
              </Typography>
            </Paper>
          </Grid>
          <Grid item xs={6} sm={2.4}>
            <Paper variant="outlined" sx={{ p: 1.5, textAlign: 'center' }}>
              <Typography variant="h3">{kpis.areas}</Typography>
              <Typography variant="caption" color="text.secondary">
                Areas Covered
              </Typography>
            </Paper>
          </Grid>
        </Grid>
      )}

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap">
          <TextField
            size="small"
            placeholder="Search Visit ID or customer"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ flex: 1, minWidth: 220 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
            }}
          />
          <TextField select size="small" label="Status" value={status} onChange={(e) => setStatus(e.target.value)} sx={{ width: 160 }}>
            <MenuItem value="All">All Statuses</MenuItem>
            <MenuItem value="Scheduled">Scheduled</MenuItem>
            <MenuItem value="Completed">Completed</MenuItem>
            <MenuItem value="Cancelled">Cancelled</MenuItem>
          </TextField>
          {mode !== 'area' && (
            <TextField select size="small" label="Area" value={areaFilter} onChange={(e) => setArea(e.target.value)} sx={{ width: 180 }}>
              <MenuItem value="All">All Areas</MenuItem>
              {serviceAreas.map((a) => (
                <MenuItem key={a.id} value={a.id}>
                  {a.name}
                </MenuItem>
              ))}
            </TextField>
          )}
          {(mode === 'day' || mode === 'area') && (
            <Chip label={mode === 'day' ? formatDate(routeDate) : serviceAreas.find((a) => a.id === areaCode)?.name} onDelete={() => navigate('/visits')} />
          )}
        </Stack>
      </Paper>

      <Paper variant="outlined" sx={{ height: 560 }}>
        {isError ? (
          <ErrorState message={error.message} onRetry={refetch} />
        ) : !isLoading && rows.length === 0 ? (
          <EmptyState title="No visits found" description="Visits are generated automatically when a booking is confirmed or a subscription is renewed." />
        ) : (
          <DataGrid
            rows={rows}
            columns={columns}
            loading={isLoading}
            checkboxSelection
            disableRowSelectionOnClick
            rowSelectionModel={selection}
            onRowSelectionModelChange={setSelection}
            onRowClick={(p) => navigate(`/visits/${p.row.visitNumber}`)}
            sx={{ border: 'none', '& .MuiDataGrid-row': { cursor: 'pointer' } }}
            initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
            pageSizeOptions={[10, 25, 50]}
          />
        )}
      </Paper>

      <CompleteVisitDialog
        open={!!completeTarget}
        onClose={() => setCompleteTarget(null)}
        visitNumbers={completeTarget || []}
      />
      <RescheduleVisitDialog open={!!rescheduleTarget} onClose={() => setRescheduleTarget(null)} visit={rescheduleTarget} />
    </>
  );
}
