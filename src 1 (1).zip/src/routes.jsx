import { Suspense, lazy } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import AppShell from "./components/AppShell";
import { InlineSpinner } from "./components/PageStates";
import ComingSoonPage from "./components/ComingSoonPage";

const CustomerListPage = lazy(
  () => import("./features/customers/CustomerListPage"),
);
const CustomerProfilePage = lazy(
  () => import("./features/customers/CustomerProfilePage"),
);
const BookingListPage = lazy(
  () => import("./features/bookings/BookingListPage"),
);
const NewBookingPage = lazy(() => import("./features/bookings/NewBookingPage"));
const BookingDetailPage = lazy(
  () => import("./features/bookings/BookingDetailPage"),
);
const SubscriptionListPage = lazy(
  () => import("./features/subscriptions/SubscriptionListPage"),
);
const SubscriptionDetailPage = lazy(
  () => import("./features/subscriptions/SubscriptionDetailPage"),
);
const DashboardPage = lazy(() => import("./features/dashboard/DashboardPage"));
const VisitListPage = lazy(() => import("./features/visits/VisitListPage"));
const VisitCalendarPage = lazy(
  () => import("./features/visits/VisitCalendarPage"),
);
const VisitDetailPage = lazy(
  () => import("./features/visits/VisitDetailPage"),
);
const PaymentListPage = lazy(
  () => import("./features/payments/PaymentListPage"),
);
const RolesPage = lazy(() => import("./features/admin/RolesPage"));
const PermissionsPage = lazy(
  () => import("./features/admin/PermissionsPage"),
);

function Suspended({ children }) {
  return <Suspense fallback={<InlineSpinner />}>{children}</Suspense>;
}

export default function AppRoutes() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<Navigate to="/customers" replace />} />
        <Route path="/dashboard" element={<Suspended><DashboardPage /></Suspended>} />

        <Route
          path="/customers"
          element={
            <Suspended>
              <CustomerListPage />
            </Suspended>
          }
        />
        <Route
          path="/customers/:customerNumber"
          element={
            <Suspended>
              <CustomerProfilePage />
            </Suspended>
          }
        />

        <Route
          path="/bookings"
          element={
            <Suspended>
              <BookingListPage />
            </Suspended>
          }
        />
        <Route
          path="/bookings/new"
          element={
            <Suspended>
              <NewBookingPage />
            </Suspended>
          }
        />
        <Route
          path="/bookings/:bookingNumber"
          element={
            <Suspended>
              <BookingDetailPage />
            </Suspended>
          }
        />

        <Route
          path="/subscriptions"
          element={
            <Suspended>
              <SubscriptionListPage />
            </Suspended>
          }
        />
        <Route
          path="/subscriptions/:subscriptionNumber"
          element={
            <Suspended>
              <SubscriptionDetailPage />
            </Suspended>
          }
        />
        <Route
          path="/subscriptions/:subscriptionNumber/renew"
          element={
            <Suspended>
              <SubscriptionDetailPage renewMode />
            </Suspended>
          }
        />

        <Route path="/visits" element={<Suspended><VisitListPage /></Suspended>} />
        <Route path="/visits/today" element={<Suspended><VisitListPage mode="today" /></Suspended>} />
        <Route path="/visits/calendar" element={<Suspended><VisitCalendarPage /></Suspended>} />
        <Route path="/visits/day/:date" element={<Suspended><VisitListPage mode="day" /></Suspended>} />
        <Route path="/visits/area/:areaCode" element={<Suspended><VisitListPage mode="area" /></Suspended>} />
        <Route path="/visits/:visitNumber" element={<Suspended><VisitDetailPage /></Suspended>} />
        <Route path="/payments" element={<Suspended><PaymentListPage /></Suspended>} />
        <Route path="/invoices" element={<ComingSoonPage title="Invoices" />} />
        <Route path="/reports" element={<ComingSoonPage title="Reports" />} />
        <Route
          path="/masters/:masterType"
          element={<ComingSoonPage title="Masters" />}
        />
        <Route
          path="/admin/roles"
          element={<Suspended><RolesPage /></Suspended>}
        />
        <Route
          path="/admin/permissions"
          element={<Suspended><PermissionsPage /></Suspended>}
        />
        <Route
          path="/admin/*"
          element={<ComingSoonPage title="Administration" />}
        />
        <Route path="/settings" element={<ComingSoonPage title="Settings" />} />
        <Route
          path="/download-center"
          element={<ComingSoonPage title="Download Center" />}
        />

        <Route path="*" element={<Navigate to="/customers" replace />} />
      </Route>
    </Routes>
  );
}
