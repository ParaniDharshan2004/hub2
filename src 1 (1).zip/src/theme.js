import { createTheme } from '@mui/material/styles';

// Palette rationale: this is a field-operations tool for a water/cleaning
// service, used mostly indoors on a laptop by telecallers and admins for
// long stretches. Deep teal reads as "water/clean" without being a cliché
// spa-teal; amber is reserved for money/attention states; business IDs
// (CUS-000124, BKG-20260911-000014...) are the load-bearing content of this
// app, so they get a monospace face everywhere to make them scannable and
// visually distinct from names/labels.
const teal = {
  50: '#EAF3F1',
  100: '#CFE6E1',
  200: '#9FCDC3',
  300: '#6BB1A4',
  400: '#3E9585',
  500: '#1F7A6C',
  600: '#166357',
  700: '#0F5C57',
  800: '#0B4642',
  900: '#08302D',
};

const amber = {
  50: '#FCF3E3',
  300: '#E8B85B',
  500: '#D98E04',
  700: '#A96C02',
};

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: teal[700],
      light: teal[500],
      dark: teal[900],
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: amber[500],
      light: amber[300],
      dark: amber[700],
      contrastText: '#1A1A1A',
    },
    success: { main: '#1F8A55' },
    warning: { main: amber[500] },
    error: { main: '#C0392B' },
    info: { main: '#2E6FA7' },
    background: {
      default: '#F5F7F6',
      paper: '#FFFFFF',
    },
    text: {
      primary: '#122522',
      secondary: '#4B5F5C',
    },
    divider: '#DDE6E3',
    teal,
    amber,
  },
  shape: {
    borderRadius: 8,
  },
  typography: {
    fontFamily: '"Inter", "Helvetica Neue", Arial, sans-serif',
    fontMonoFamily: '"IBM Plex Mono", "Roboto Mono", monospace',
    h1: { fontSize: '2rem', fontWeight: 700, letterSpacing: '-0.01em' },
    h2: { fontSize: '1.5rem', fontWeight: 700, letterSpacing: '-0.01em' },
    h3: { fontSize: '1.25rem', fontWeight: 600 },
    h4: { fontSize: '1.05rem', fontWeight: 600 },
    subtitle1: { fontSize: '0.95rem', fontWeight: 600 },
    body2: { fontSize: '0.875rem' },
    button: { textTransform: 'none', fontWeight: 600 },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: 6, paddingInline: 16 },
      },
      defaultProps: { disableElevation: true },
    },
    MuiPaper: {
      styleOverrides: {
        root: { backgroundImage: 'none' },
      },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: '#FFFFFF',
          color: '#122522',
          borderBottom: `1px solid ${'#DDE6E3'}`,
        },
      },
      defaultProps: { elevation: 0 },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          backgroundColor: teal[900],
          color: '#EAF3F1',
          borderRight: 'none',
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 600 },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: { borderColor: '#DDE6E3' },
      },
    },
  },
});

export default theme;
