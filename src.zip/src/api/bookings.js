import dayjs from 'dayjs';
import { getDb, saveDb, recordAudit, recordStatusChange } from './db';
import { generateId } from '../utils/idGenerator';
import { delay, plans, frequencies, taxComponents, visitsForPlan } from './masters';

export function quotePricing({ planId, frequencyId, bathrooms, discount = 0 }) {
  const plan = plans.find((p) => p.id === planId);
  const frequency = frequencies.find((f) => f.id === frequencyId);
  if (!plan || !frequency || !bathrooms) return null;

  const pricePerService = plan.pricePerServiceByBathroom[bathrooms];
  if (!pricePerService) return null;

  const numServices = visitsForPlan(plan, frequency);
  const serviceCharges = round2(pricePerService * numServices);
  const authorizedDiscount = round2(Math.min(discount || 0, serviceCharges));
  const taxableAmount = round2(serviceCharges - authorizedDiscount);

  const taxes = taxComponents.map((t) => ({
    ...t,
    amount: round2(taxableAmount * t.rate),
  }));
  const taxTotal = round2(taxes.reduce((s, t) => s + t.amount, 0));
  const total = round2(taxableAmount + taxTotal);

  return {
    plan,
    frequency,
    pricePerService,
    numServices,
    serviceCharges,
    authorizedDiscount,
    taxableAmount,
    taxes,
    taxTotal,
    total,
    effectiveDate: dayjs().format('YYYY-MM-DD'),
  };
}

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

function toBookingRow(booking) {
  const db = getDb();
  const customer = db.customers.find((c) => c.id === booking.customerId);
  const address = db.addresses.find((a) => a.id === booking.addressId);
  return { ...booking, customer, address };
}

export async function listBookings({ search = '', status = 'All' } = {}) {
  await delay();
  const db = getDb();
  let rows = db.bookings.map(toBookingRow);

  if (status !== 'All') rows = rows.filter((b) => b.status === status);
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (b) =>
        b.bookingNumber.toLowerCase().includes(q) ||
        b.customer?.name.toLowerCase().includes(q) ||
        b.customer?.customerNumber.toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn));
}

export async function getBooking(bookingNumber) {
  await delay(250);
  const db = getDb();
  const booking = db.bookings.find((b) => b.bookingNumber === bookingNumber);
  if (!booking) return null;
  const payment = db.payments.find((p) => p.bookingId === booking.id);
  const invoice = db.invoices.find((i) => i.bookingId === booking.id);
  const subscription = db.subscriptions.find((s) => s.id === booking.subscriptionId);
  const period = db.periods.find((p) => p.bookingId === booking.id);
  const visits = period ? db.visits.filter((v) => v.periodId === period.id) : [];
  return { ...toBookingRow(booking), payment, invoice, subscription, period, visits };
}


export async function createDraftBooking(payload) {
  await delay(350);
  const db = getDb();

  const quote = quotePricing(payload);
  if (!quote) throw new Error('Unable to price this combination.');

  const booking = {
    id: `int-bkg-${db.bookings.length + 1}-${Date.now()}`,
    bookingNumber: generateId.booking(),
    type: payload.bookingType || 'New',
    customerId: payload.customerId,
    addressId: payload.addressId,
    offeringId: payload.offeringId,
    bathrooms: payload.bathrooms,
    frequencyId: payload.frequencyId,
    planId: payload.planId,
    pricePerService: quote.pricePerService,
    numServices: quote.numServices,
    serviceCharges: quote.serviceCharges,
    discount: quote.authorizedDiscount,
    discountReason: payload.discountReason || null,
    taxableAmount: quote.taxableAmount,
    taxes: quote.taxes,
    total: quote.total,
    startDate: payload.startDate,
    slotId: payload.slotId,
    status: 'Draft',
    createdOn: new Date().toISOString(),
    confirmedOn: null,
    subscriptionId: null,
  };
  db.bookings.push(booking);

  recordAudit({
    module: 'Bookings',
    action: 'CREATE_DRAFT',
    entityType: 'Booking',
    entityNumber: booking.bookingNumber,
  });

  saveDb();
  return toBookingRow(booking);
}

// Atomic confirmation: in a real backend this is one DB transaction. Here
// we mutate the mock tables synchronously (no await between steps) so the
// "all or nothing" contract is honestly represented, then persist once at
// the end.
export async function confirmBooking(bookingNumber, { paymentModeId, paymentReference }) {
  await delay(500);
  const db = getDb();
  const booking = db.bookings.find((b) => b.bookingNumber === bookingNumber);
  if (!booking) throw new Error('Booking not found');
  if (booking.status !== 'Draft') throw new Error('Only draft bookings can be confirmed.');
  if (!paymentModeId) throw new Error('Payment mode is required to confirm a booking.');

  try {
    const now = new Date();

    // 1. Payment
    const payment = {
      id: `int-pay-${db.payments.length + 1}-${Date.now()}`,
      paymentNumber: generateId.payment(now),
      bookingId: booking.id,
      customerId: booking.customerId,
      amount: booking.total,
      modeId: paymentModeId,
      reference: paymentReference || null,
      paymentDate: now.toISOString(),
      status: 'Recorded',
    };
    db.payments.push(payment);

    // 2. Invoice (immutable financial document)
    const invoice = {
      id: `int-inv-${db.invoices.length + 1}-${Date.now()}`,
      invoiceNumber: generateId.invoice(now),
      bookingId: booking.id,
      customerId: booking.customerId,
      paymentId: payment.id,
      amount: booking.total,
      taxableAmount: booking.taxableAmount,
      taxes: booking.taxes,
      date: now.toISOString(),
    };
    db.invoices.push(invoice);

    // 3. Subscription account: continuing relationship keyed by
    // customer + address + offering. Find existing or create new — never
    // duplicate the continuing account itself.
    let subscription = db.subscriptions.find(
      (s) =>
        s.customerId === booking.customerId &&
        s.addressId === booking.addressId &&
        s.offeringId === booking.offeringId
    );
    if (!subscription) {
      subscription = {
        id: `int-sub-${db.subscriptions.length + 1}-${Date.now()}`,
        subscriptionNumber: generateId.subscription(),
        customerId: booking.customerId,
        addressId: booking.addressId,
        offeringId: booking.offeringId,
        status: 'Active',
        createdOn: now.toISOString(),
      };
      db.subscriptions.push(subscription);
    } else {
      subscription.status = 'Active';
    }
    booking.subscriptionId = subscription.id;

    // 4. Subscription period — one immutable purchased term.
    const startDate = dayjs(booking.startDate);
    const plan = plans.find((p) => p.id === booking.planId);
    const endDate = startDate.add(plan.termMonths, 'month').subtract(1, 'day');
    const period = {
      id: `int-per-${db.periods.length + 1}-${Date.now()}`,
      periodNumber: generateId.period(),
      subscriptionId: subscription.id,
      bookingId: booking.id,
      planId: booking.planId,
      frequencyId: booking.frequencyId,
      totalServices: booking.numServices,
      completedServices: 0,
      remainingServices: booking.numServices,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      status: 'Active',
      kind: subscription.createdOn === now.toISOString() ? 'Initial' : 'Renewal',
    };
    db.periods.push(period);

    // 5. Generate service visits spread evenly across the term.
    const frequency = frequencies.find((f) => f.id === booking.frequencyId);
    const intervalDays = Math.max(1, Math.round(28 / frequency.visitsPerMonth));
    for (let i = 0; i < booking.numServices; i += 1) {
      const visitDate = startDate.add(i * intervalDays, 'day');
      db.visits.push({
        id: `int-visit-${db.visits.length + 1}-${Date.now()}-${i}`,
        visitNumber: generateId.visit(visitDate.toDate()),
        periodId: period.id,
        subscriptionId: subscription.id,
        sequence: i + 1,
        date: visitDate.toISOString(),
        slotId: booking.slotId,
        areaId: db.addresses.find((a) => a.id === booking.addressId)?.area,
        status: 'Scheduled',
      });
    }

    // 6. Flip booking status last, atomically with everything above.
    const fromStatus = booking.status;
    booking.status = 'Confirmed';
    booking.confirmedOn = now.toISOString();

    recordStatusChange({
      entityType: 'Booking',
      entityNumber: booking.bookingNumber,
      fromStatus,
      toStatus: 'Confirmed',
    });
    recordAudit({
      module: 'Bookings',
      action: 'CONFIRM',
      entityType: 'Booking',
      entityNumber: booking.bookingNumber,
      details: `Invoice ${invoice.invoiceNumber}, Payment ${payment.paymentNumber}, Subscription ${subscription.subscriptionNumber}`,
    });

    saveDb();
    return {
      booking: toBookingRow(booking),
      payment,
      invoice,
      subscription,
      period,
      visitsCreated: booking.numServices,
    };
  } catch (err) {
    // Nothing was persisted (saveDb only runs on the success path), so a
    // thrown error here leaves storage exactly as it was before this call.
    throw err;
  }
}

export async function cancelBooking(bookingNumber, reason) {
  await delay(300);
  const db = getDb();
  const booking = db.bookings.find((b) => b.bookingNumber === bookingNumber);
  if (!booking) throw new Error('Booking not found');
  if (booking.status === 'Confirmed') {
    throw new Error('Confirmed bookings cannot be cancelled here; reverse the payment first.');
  }
  const fromStatus = booking.status;
  booking.status = 'Cancelled';
  recordStatusChange({
    entityType: 'Booking',
    entityNumber: booking.bookingNumber,
    fromStatus,
    toStatus: 'Cancelled',
    reason,
  });
  recordAudit({ module: 'Bookings', action: 'CANCEL', entityType: 'Booking', entityNumber: booking.bookingNumber });
  saveDb();
  return toBookingRow(booking);
}
