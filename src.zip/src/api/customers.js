import { getDb, saveDb, recordAudit } from "./db";
import { generateId } from "../utils/idGenerator";
import { delay } from "./masters";

function toCustomerRow(customer) {
  const db = getDb();
  const addresses = db.addresses.filter((a) => a.customerId === customer.id);
  const activeAddresses = addresses.filter((a) => a.status === "Active");
  const bookings = db.bookings.filter((b) => b.customerId === customer.id);
  const subscriptions = db.subscriptions.filter(
    (s) => s.customerId === customer.id,
  );
  const activeSubscriptions = subscriptions.filter(
    (s) => s.status === "Active",
  );
  const payments = db.payments.filter(
    (p) => p.customerId === customer.id && p.status !== "Reversed",
  );
  const lifetimeCollected = payments.reduce((sum, p) => sum + p.amount, 0);

  const upcomingVisits = db.visits
    .filter(
      (v) =>
        subscriptions.some((s) => s.id === v.subscriptionId) &&
        v.status === "Scheduled",
    )
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  return {
    ...customer,
    defaultAddress: addresses.find((a) => a.isDefault) || addresses[0] || null,
    addressCount: activeAddresses.length,
    activeSubscriptionCount: activeSubscriptions.length,
    nextVisit: upcomingVisits[0] || null,
    lifetimeCollected,
  };
}

export async function listCustomers({ search = "", status = "All" } = {}) {
  await delay();
  const db = getDb();
  let rows = db.customers.map(toCustomerRow);

  if (status !== "All") {
    rows = rows.filter((c) => c.status === status);
  }
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (c) =>
        c.customerNumber.toLowerCase().includes(q) ||
        c.name.toLowerCase().includes(q) ||
        c.mobile.includes(q) ||
        (c.email || "").toLowerCase().includes(q),
    );
  }
  return rows.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn));
}

export async function getCustomerByNumber(customerNumber) {
  await delay(150);
  const db = getDb();
  const customer = db.customers.find(
    (c) => c.customerNumber === customerNumber,
  );
  return customer ? toCustomerRow(customer) : null;
}

export async function listAddressesForCustomer(customerId) {
  await delay(150);
  const db = getDb();
  return db.addresses.filter(
    (a) => a.customerId === customerId && a.status === "Active",
  );
}

export async function findByMobile(mobile) {
  await delay(150);
  const db = getDb();
  return db.customers.filter((c) => c.mobile === mobile).map(toCustomerRow);
}

export async function createCustomerWithAddress(payload) {
  await delay(400);
  const db = getDb();

  const customer = {
    id: `int-cust-${db.customers.length + 1}-${Date.now()}`,
    customerNumber: generateId.customer(),
    name: payload.name,
    mobile: payload.mobile,
    whatsapp: payload.sameAsMobile ? payload.mobile : payload.whatsapp || "",
    email: payload.email || "",
    status: "Active",
    createdOn: new Date().toISOString(),
  };
  db.customers.push(customer);

  const address = {
    id: `int-addr-${db.addresses.length + 1}-${Date.now()}`,
    addressNumber: generateId.address(),
    customerId: customer.id,
    label: payload.addressLabel || "Home",
    doorNo: payload.doorNo || "",
    block: payload.block || "",
    community: payload.community || "",
    addressLine: payload.addressLine || "",
    area: payload.area,
    city: payload.city || "",
    pincode: payload.pincode || "",
    landmark: payload.landmark || "",
    isDefault: true,
    status: "Active",
    createdOn: customer.createdOn,
  };
  db.addresses.push(address);

  recordAudit({
    module: "Customers",
    action: "CREATE",
    entityType: "Customer",
    entityNumber: customer.customerNumber,
    details: `Created with first address ${address.addressNumber}`,
  });

  saveDb();
  return { customer: toCustomerRow(customer), address };
}

export async function addAddress(customerNumber, payload) {
  await delay(350);
  const db = getDb();
  const customer = db.customers.find(
    (c) => c.customerNumber === customerNumber,
  );
  if (!customer) throw new Error("Customer not found");

  if (payload.isDefault) {
    db.addresses
      .filter((a) => a.customerId === customer.id)
      .forEach((a) => {
        a.isDefault = false;
      });
  }

  const address = {
    id: `int-addr-${db.addresses.length + 1}-${Date.now()}`,
    addressNumber: generateId.address(),
    customerId: customer.id,
    label: payload.addressLabel || "Address",
    doorNo: payload.doorNo || "",
    block: payload.block || "",
    community: payload.community || "",
    addressLine: payload.addressLine || "",
    area: payload.area,
    city: payload.city || "",
    pincode: payload.pincode || "",
    landmark: payload.landmark || "",
    isDefault:
      !!payload.isDefault ||
      db.addresses.filter((a) => a.customerId === customer.id).length === 0,
    status: "Active",
    createdOn: new Date().toISOString(),
  };
  db.addresses.push(address);

  recordAudit({
    module: "Customers",
    action: "ADD_ADDRESS",
    entityType: "Customer",
    entityNumber: customer.customerNumber,
    details: `Added address ${address.addressNumber}`,
  });

  saveDb();
  return address;
}

export async function getCustomer360(customerNumber) {
  await delay(300);
  const db = getDb();
  const customer = db.customers.find(
    (c) => c.customerNumber === customerNumber,
  );
  if (!customer) return null;

  const addresses = db.addresses.filter((a) => a.customerId === customer.id);
  const bookings = db.bookings
    .filter((b) => b.customerId === customer.id)
    .sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn));
  const subscriptions = db.subscriptions
    .filter((s) => s.customerId === customer.id)
    .map((s) => {
      const periods = db.periods
        .filter((p) => p.subscriptionId === s.id)
        .sort((a, b) => new Date(b.startDate) - new Date(a.startDate));
      const currentPeriod = periods[0] || null;
      const visits = currentPeriod
        ? db.visits.filter((v) => v.periodId === currentPeriod.id)
        : [];
      return { ...s, periods, currentPeriod, visits };
    });
  const payments = db.payments.filter((p) => p.customerId === customer.id);
  const invoices = db.invoices.filter((i) => i.customerId === customer.id);
  const visits = db.visits.filter((v) =>
    subscriptions.some((s) => s.id === v.subscriptionId),
  );
  const auditEvents = db.auditLog.filter(
    (a) => a.entityNumber === customer.customerNumber,
  );

  const lifetimeCollected = payments
    .filter((p) => p.status !== "Reversed")
    .reduce((sum, p) => sum + p.amount, 0);

  const upcomingVisits = visits
    .filter((v) => v.status === "Scheduled")
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  return {
    customer,
    addresses,
    bookings,
    subscriptions,
    payments,
    invoices,
    visits,
    auditEvents,
    summary: {
      addressCount: addresses.filter((a) => a.status === "Active").length,
      totalBookings: bookings.length,
      activeSubscriptions: subscriptions.filter((s) => s.status === "Active")
        .length,
      visitsCompleted: visits.filter((v) => v.status === "Completed").length,
      lifetimeCollected,
      nextVisits: upcomingVisits.slice(0, 2),
    },
  };
}

export async function deactivateCustomer(customerNumber) {
  await delay(300);
  const db = getDb();
  const customer = db.customers.find(
    (c) => c.customerNumber === customerNumber,
  );
  if (!customer) throw new Error("Customer not found");
  const hasActiveSub = db.subscriptions.some(
    (s) => s.customerId === customer.id && s.status === "Active",
  );
  if (hasActiveSub) {
    throw new Error("Cannot deactivate: customer has active subscriptions.");
  }
  customer.status = "Inactive";
  recordAudit({
    module: "Customers",
    action: "DEACTIVATE",
    entityType: "Customer",
    entityNumber: customer.customerNumber,
  });
  saveDb();
  return customer;
}
