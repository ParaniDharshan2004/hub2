// Mock persistence layer standing in for the real backend/API. Everything
// here is written the way a thin backend service would be: normalized
// tables, foreign keys by internal id, business numbers generated once and
// never reused. Swap this module for real HTTP calls (e.g. via the
// TanStack Query hooks in customers.js/bookings.js/subscriptions.js)
// without touching any screen code.
import dayjs from 'dayjs';
import { generateId } from '../utils/idGenerator';

const STORAGE_KEY = 'tco_mock_db_v1';

function emptyDb() {
  return {
    customers: [],
    addresses: [],
    bookings: [],
    payments: [],
    invoices: [],
    subscriptions: [],
    periods: [],
    visits: [],
    statusHistory: [],
    auditLog: [],
  };
}

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    // ignore corrupt storage, fall through to a fresh db
  }
  return null;
}

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch (e) {
    // storage may be unavailable (private mode / quota) — app still works
    // in-memory for the session.
  }
}

let db = load() || emptyDb();

export function resetDb() {
  db = emptyDb();
  persist();
}

export function recordAudit({ module, action, entityType, entityNumber, actor = 'Demo Admin', details }) {
  db.auditLog.push({
    id: `AUD-${db.auditLog.length + 1}`,
    module,
    action,
    entityType,
    entityNumber,
    actor,
    details: details || null,
    createdOn: new Date().toISOString(),
  });
}

export function recordStatusChange({ entityType, entityNumber, fromStatus, toStatus, reason }) {
  db.statusHistory.push({
    id: `STH-${db.statusHistory.length + 1}`,
    entityType,
    entityNumber,
    fromStatus,
    toStatus,
    reason: reason || null,
    actor: 'Demo Admin',
    createdOn: new Date().toISOString(),
  });
}

// ---------------------------------------------------------------------
// Seed data — gives the app something to look at on first run.
// ---------------------------------------------------------------------
function seedIfEmpty() {
  if (db.customers.length > 0) return;

  const seedCustomers = [
    { name: 'Ananya Rao', mobile: '9880011223', whatsapp: '9880011223', email: 'ananya.rao@example.com' },
    { name: 'Vikram Shetty', mobile: '9845566778', whatsapp: '9845566778', email: '' },
    { name: 'Farah Khan', mobile: '9900112233', whatsapp: '', email: 'farah.khan@example.com' },
      
  ];

  const seedAddressData = [
    { label: 'Home', area: 'AREA-01', city: 'Bengaluru', pincode: '560038', addressLine: '3rd Cross, Defence Colony' },
    { label: 'Office', area: 'AREA-02', city: 'Bengaluru', pincode: '560034', addressLine: '80 Feet Road' },
    { label: 'Home', area: 'AREA-04', city: 'Bengaluru', pincode: '560102', addressLine: 'Sector 2, HSR Layout' },
  ];

  seedCustomers.forEach((c, idx) => {
    const customer = {
      id: `int-cust-${idx + 1}`,
      customerNumber: generateId.customer(),
      ...c,
      status: 'Active',
      createdOn: dayjs().subtract(30 - idx * 5, 'day').toISOString(),
    };
    db.customers.push(customer);

    const addr = seedAddressData[idx];
    const address = {
      id: `int-addr-${idx + 1}`,
      addressNumber: generateId.address(),
      customerId: customer.id,
      label: addr.label,
      doorNo: `${idx + 1}0A`,
      block: '',
      community: '',
      addressLine: addr.addressLine,
      area: addr.area,
      city: addr.city,
      pincode: addr.pincode,
      landmark: '',
      isDefault: true,
      status: 'Active',
      createdOn: customer.createdOn,
    };
    db.addresses.push(address);
  });

  persist();
}
seedIfEmpty();

export function getDb() {
  return db;
}

export function saveDb() {
  persist();
}
