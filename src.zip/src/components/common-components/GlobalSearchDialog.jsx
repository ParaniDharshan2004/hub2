import React from 'react';
import {
  Dialog,
  DialogContent,
  List,
  ListItemButton,
  ListItemText,
  TextField,
  Typography,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { getDb } from '../../api/db';

export default function GlobalSearchDialog({ open, onClose }) {
  const navigate = useNavigate();
  const [query, setQuery] = React.useState('');

  React.useEffect(() => {
    if (open) setQuery('');
  }, [open]);

  const data = getDb();
  const source = [
    ...data.customers.map((customer) => ({
      label: customer.customerNumber,
      detail: `${customer.name} · ${customer.mobile}`,
      path: `/customers/${customer.customerNumber}`,
    })),
    ...data.bookings.map((booking) => ({
      label: booking.bookingNumber,
      detail: `${booking.type} booking · ${booking.status}`,
      path: `/bookings/${booking.bookingNumber}`,
    })),
    ...data.subscriptions.map((subscription) => ({
      label: subscription.subscriptionNumber,
      detail: `Subscription · ${subscription.status}`,
      path: `/subscriptions/${subscription.subscriptionNumber}`,
    })),
  ];

  const rows = source
    .filter((item) => `${item.label} ${item.detail}`.toLowerCase().includes(query.toLowerCase()))
    .slice(0, 10);

  const handleSelect = (path) => {
    onClose();
    navigate(path);
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogContent>
        <Typography variant="overline" color="text.secondary">
          Global search · Ctrl/Cmd + K
        </Typography>
        <TextField
          autoFocus
          fullWidth
          size="small"
          label="Search customers, bookings and subscriptions"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          sx={{ my: 1.5 }}
        />
        <List>
          {rows.map((row) => (
            <ListItemButton key={`${row.path}-${row.label}`} onClick={() => handleSelect(row.path)}>
              <ListItemText primary={row.label} secondary={row.detail} />
            </ListItemButton>
          ))}
          {query && rows.length === 0 && (
            <ListItemText sx={{ px: 2, py: 1 }} primary="No matching records" />
          )}
        </List>
      </DialogContent>
    </Dialog>
  );
}