import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import { Link as RouterLink } from "react-router-dom";

export default function PageHeader({
  title,
  subtitle,
  breadcrumbs,
  statusSlot,
  actions,
}) {
  return (
    <Box sx={{ mb: 3 }}>
      {breadcrumbs && breadcrumbs.length > 0 && (
        <Breadcrumbs sx={{ mb: 0.5, fontSize: "0.8rem" }}>
          {breadcrumbs.map((b, i) =>
            b.to ? (
              <Box
                key={i}
                component={RouterLink}
                to={b.to}
                sx={{
                  color: "text.secondary",
                  textDecoration: "none",
                  "&:hover": { textDecoration: "underline" },
                }}
              >
                {b.label}
              </Box>
            ) : (
              <Typography key={i} variant="body2" color="text.secondary">
                {b.label}
              </Typography>
            ),
          )}
        </Breadcrumbs>
      )}
      <Stack
        direction={{ xs: "column", sm: "row" }}
        spacing={2}
        justifyContent="space-between"
        alignItems={{ sm: "center" }}
      >
        <Stack
          direction="row"
          spacing={1.5}
          alignItems="center"
          flexWrap="wrap"
        >
          <Typography
            variant="h1"
            sx={{ fontSize: { xs: "1.4rem", sm: "1.75rem" } }}
          >
            {title}
          </Typography>
          {statusSlot}
        </Stack>
        {actions && (
          <Stack direction="row" spacing={1} flexWrap="wrap">
            {actions}
          </Stack>
        )}
      </Stack>
      {subtitle && (
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
          {subtitle}
        </Typography>
      )}
    </Box>
  );
}
