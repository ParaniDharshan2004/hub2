import Chip from "@mui/material/Chip";

// Single source of truth for status labels/colors across the app, per the
// spec's requirement to centralize status presentation and never rely on
// color alone (label text always carries the meaning).
const STATUS_MAP = {
  Active: { color: "success", label: "Active" },
  Inactive: { color: "default", label: "Inactive" },
  Draft: { color: "warning", label: "Draft" },
  Confirmed: { color: "success", label: "Confirmed" },
  Cancelled: { color: "error", label: "Cancelled" },
  Scheduled: { color: "info", label: "Scheduled" },
  Completed: { color: "success", label: "Completed" },
  Rescheduled: { color: "warning", label: "Rescheduled" },
  Expired: { color: "default", label: "Expired" },
  Recorded: { color: "success", label: "Recorded" },
  Reversed: { color: "error", label: "Reversed" },
  "On Track": { color: "success", label: "On Track" },
  "Renewal Due Soon": { color: "warning", label: "Renewal Due Soon" },
  "Renewal Overdue": { color: "error", label: "Renewal Overdue" },
  "No Period": { color: "default", label: "No Period" },
};

export default function StatusChip({ status, size = "small" }) {
  const meta = STATUS_MAP[status] || {
    color: "default",
    label: status || "Unknown",
  };
  return (
    <Chip
      size={size}
      color={meta.color}
      label={meta.label}
      variant={meta.color === "default" ? "outlined" : "filled"}
    />
  );
}
