import { useNavigate } from 'react-router-dom';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import LinearProgress from '@mui/material/LinearProgress';
import EntityLink from '../common-components/EntityLink';
import StatusChip from '../common-components/StatusChip';
import { EmptyState } from '../common-components/PageStates';
import { plans, serviceAreas } from '../../api/masters';
import { formatDate } from '../../utils/format';

export default function SubscriptionsTab({ subscriptions, addresses }) {
  const navigate = useNavigate();

  if (subscriptions.length === 0) {
    return (
      <Paper variant="outlined">
        <EmptyState
          title="No subscriptions yet"
          description="Subscriptions are created automatically once a booking is confirmed."
        />
      </Paper>
    );
  }

  const grouped = addresses
    .map((addr) => ({ addr, subs: subscriptions.filter((s) => s.addressId === addr.id) }))
    .filter((g) => g.subs.length > 0);

  return (
    <Stack spacing={3}>
      {grouped.map(({ addr, subs }) => (
        <div key={addr.id}>
          <Typography variant="subtitle1" sx={{ mb: 1 }}>
            {addr.label} · {serviceAreas.find((a) => a.id === addr.area)?.name}
          </Typography>
          <Grid container spacing={2}>
            {subs.map((s) => {
              const period = s.currentPeriod;
              const plan = period ? plans.find((p) => p.id === period.planId) : null;
              const pct = period ? Math.round((period.completedServices / period.totalServices) * 100) : 0;
              return (
                <Grid item xs={12} md={6} key={s.id}>
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                      <EntityLink type="Subscription" id={s.subscriptionNumber} />
                      <StatusChip status={s.status} />
                    </Stack>
                    <Typography variant="body2" sx={{ mt: 1 }}>
                      {plan?.name || '—'}
                    </Typography>
                    {period && (
                      <>
                        <LinearProgress variant="determinate" value={pct} sx={{ my: 1, height: 6, borderRadius: 3 }} />
                        <Typography variant="caption" color="text.secondary">
                          {period.completedServices}/{period.totalServices} services · ends {formatDate(period.endDate)}
                        </Typography>
                        <br />
                        <StatusChip status={s.renewalStatus} size="small" />
                      </>
                    )}
                    <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
                      <Button size="small" onClick={() => navigate(`/subscriptions/${s.subscriptionNumber}`)}>
                        View
                      </Button>
                      <Button size="small" variant="outlined" onClick={() => navigate(`/subscriptions/${s.subscriptionNumber}/renew`)}>
                        Renew
                      </Button>
                    </Stack>
                  </Paper>
                </Grid>
              );
            })}
          </Grid>
        </div>
      ))}
    </Stack>
  );
}
