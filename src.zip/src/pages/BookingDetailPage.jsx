import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';

import PageHeader from '../components/common-components/PageHeader';
import StatusChip from '../components/common-components/StatusChip';
import Money from '../components/common-components/Money';
import EntityLink from '../components/common-components/EntityLink';
import ConfirmDialog from '../components/bookingdetail-components/ConfirmDialog';
import { LoadingSkeleton, ErrorState } from '../components/common-components/PageStates';
import { useSnackbar } from '../components/common-components/SnackbarProvider';
import { getBooking, confirmBooking, cancelBooking } from '../api/bookings';
import { serviceAreas, plans, frequencies, serviceSlots, paymentModes, serviceOfferings } from '../api/masters';
import { formatDate, formatDateTime } from '../utils/format';

export default function BookingDetailPage() {
  const { bookingNumber } = useParams();
  const navigate = useNavigate();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [paymentModeId, setPaymentModeId] = useState('');

  const { data: booking, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['booking', bookingNumber],
    queryFn: () => getBooking(bookingNumber),
  });

  const confirmMutation = useMutation({
    mutationFn: () => confirmBooking(bookingNumber, { paymentModeId }),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['booking', bookingNumber] });
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
      queryClient.invalidateQueries({ queryKey: ['customer360'] });
      snackbar.success(`Payment ${result.payment.paymentNumber} recorded successfully.`);
      snackbar.success(`Booking confirmed. Invoice ${result.invoice.invoiceNumber} is ready.`);
      setConfirmOpen(false);
    },
    onError: (err) => snackbar.error(err.message),
  });

  const cancelMutation = useMutation({
    mutationFn: (reason) => cancelBooking(bookingNumber, reason),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['booking', bookingNumber] });
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
      snackbar.success(`Booking ${bookingNumber} cancelled.`);
      setCancelOpen(false);
    },
    onError: (err) => snackbar.error(err.message),
  });

  if (isLoading) {
    return (
      <>
        <PageHeader title="Loading booking…" breadcrumbs={[{ label: 'Bookings', to: '/bookings' }, { label: bookingNumber }]} />
        <LoadingSkeleton rows={8} />
      </>
    );
  }
  if (isError) return <ErrorState message={error.message} onRetry={refetch} />;
  if (!booking) return <ErrorState message={`Booking ${bookingNumber} was not found.`} />;

  return (
    <>
      <PageHeader
        title={booking.bookingNumber}
        breadcrumbs={[{ label: 'Bookings', to: '/bookings' }, { label: booking.bookingNumber }]}
        statusSlot={<StatusChip status={booking.status} />}
        actions={
          booking.status === 'Draft' ? (
            <>
              <Button variant="outlined" color="error" onClick={() => setCancelOpen(true)}>
                Cancel Booking
              </Button>
              <Button variant="contained" onClick={() => setConfirmOpen(true)}>
                Confirm Booking
              </Button>
            </>
          ) : null
        }
      />

      <Grid container spacing={3}>
        <Grid item xs={12} md={7}>
          <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 }, mb: 3 }}>
            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Customer & Address
            </Typography>
            <Stack spacing={0.5}>
              <Stack direction="row" spacing={1} alignItems="center">
                <EntityLink type="Customer" id={booking.customer?.customerNumber} />
                <Typography variant="body2">{booking.customer?.name}</Typography>
              </Stack>
              <Typography variant="body2" color="text.secondary">
                {booking.address?.label}, {serviceAreas.find((a) => a.id === booking.address?.area)?.name}
              </Typography>
            </Stack>

            <Divider sx={{ my: 2 }} />

            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Service Details
            </Typography>
            <Grid container spacing={1.5}>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Offering
                </Typography>
                <Typography variant="body2">{serviceOfferings.find((o) => o.id === booking.offeringId)?.name}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Bathrooms
                </Typography>
                <Typography variant="body2">{booking.bathrooms}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Frequency
                </Typography>
                <Typography variant="body2">{frequencies.find((f) => f.id === booking.frequencyId)?.name}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Plan
                </Typography>
                <Typography variant="body2">{plans.find((p) => p.id === booking.planId)?.name}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Start Date
                </Typography>
                <Typography variant="body2">{formatDate(booking.startDate)}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Slot
                </Typography>
                <Typography variant="body2">{serviceSlots.find((s) => s.id === booking.slotId)?.label}</Typography>
              </Grid>
            </Grid>
          </Paper>

          <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 } }}>
            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Related Records
            </Typography>
            <List dense disablePadding>
              <ListItem disableGutters>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 100 }}>
                        Payment
                      </Typography>
                      {booking.payment ? <EntityLink type="Payment" id={booking.payment.paymentNumber} /> : <Typography variant="body2" color="text.secondary">Not recorded yet</Typography>}
                    </Stack>
                  }
                />
              </ListItem>
              <ListItem disableGutters>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 100 }}>
                        Invoice
                      </Typography>
                      {booking.invoice ? <EntityLink type="Invoice" id={booking.invoice.invoiceNumber} /> : <Typography variant="body2" color="text.secondary">Not generated yet</Typography>}
                    </Stack>
                  }
                />
              </ListItem>
              <ListItem disableGutters>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 100 }}>
                        Subscription
                      </Typography>
                      {booking.subscription ? <EntityLink type="Subscription" id={booking.subscription.subscriptionNumber} /> : <Typography variant="body2" color="text.secondary">Created on confirmation</Typography>}
                    </Stack>
                  }
                />
              </ListItem>
              <ListItem disableGutters>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 100 }}>
                        Visits
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {booking.visits?.length ? `${booking.visits.length} scheduled` : 'Generated on confirmation'}
                      </Typography>
                    </Stack>
                  }
                />
              </ListItem>
            </List>
          </Paper>
        </Grid>

        <Grid item xs={12} md={5}>
          <Paper variant="outlined" sx={{ p: 2.5 }}>
            <Typography variant="subtitle1" sx={{ mb: 1.5 }}>
              Bill Summary
            </Typography>
            <Stack spacing={0.75}>
              <Row label="Service Charges" value={booking.serviceCharges} />
              {booking.discount > 0 && <Row label="Authorized Discount" value={-booking.discount} />}
              <Row label="Taxable Amount" value={booking.taxableAmount} />
              {booking.taxes?.map((t) => (
                <Row key={t.id} label={`${t.label} (${(t.rate * 100).toFixed(0)}%)`} value={t.amount} />
              ))}
              <Divider sx={{ my: 0.5 }} />
              <Row label="Total Amount" value={booking.total} strong />
            </Stack>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1.5 }}>
              Created {formatDateTime(booking.createdOn)}
              {booking.confirmedOn && <> · Confirmed {formatDateTime(booking.confirmedOn)}</>}
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      <ConfirmDialogWithPayment
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        paymentModeId={paymentModeId}
        setPaymentModeId={setPaymentModeId}
        onConfirm={() => confirmMutation.mutate()}
        submitting={confirmMutation.isPending}
        bookingNumber={booking.bookingNumber}
      />

      <ConfirmDialog
        open={cancelOpen}
        title="Cancel Booking"
        description="This cancels the draft booking. Confirmed bookings cannot be cancelled here."
        entityLabel={booking.bookingNumber}
        requireReason
        destructive
        confirmLabel="Cancel Booking"
        onConfirm={(reason) => cancelMutation.mutateAsync(reason)}
        onClose={() => setCancelOpen(false)}
      />
    </>
  );
}

function Row({ label, value, strong }) {
  return (
    <Stack direction="row" justifyContent="space-between">
      <Typography variant="body2" color="text.secondary">
        {label}
      </Typography>
      <Money value={value} strong={strong} />
    </Stack>
  );
}

function ConfirmDialogWithPayment({ open, onClose, paymentModeId, setPaymentModeId, onConfirm, bookingNumber }) {
  return (
    <ConfirmDialog
      open={open}
      title="Confirm Booking"
      description="Record the payment already collected and confirm this booking. This generates the invoice, activates the subscription, and schedules all service visits."
      entityLabel={bookingNumber}
      confirmLabel="Confirm Booking"
      onClose={onClose}
      onConfirm={async () => {
        if (!paymentModeId) return;
        await onConfirm();
      }}
      confirmDisabled={!paymentModeId}
    >
      <TextField
        select
        fullWidth
        label="Payment Mode Received"
        required
        value={paymentModeId}
        onChange={(e) => setPaymentModeId(e.target.value)}
        sx={{ mt: 2 }}
      >
        {paymentModes.map((m) => (
          <MenuItem key={m.id} value={m.id}>
            {m.name}
          </MenuItem>
        ))}
      </TextField>
    </ConfirmDialog>
  );
}
