import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import Chip from '@mui/material/Chip';
import Typography from '@mui/material/Typography';
import { DataGrid } from '@mui/x-data-grid';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';
import MoreVertIcon from '@mui/icons-material/MoreVert';

import PageHeader from '../components/common-components/PageHeader';
import EntityLink from '../components/common-components/EntityLink';
import StatusChip from '../components/common-components/StatusChip';
import Money from '../components/common-components/Money';
import { EmptyState, ErrorState } from '../components/common-components/PageStates';
import { listCustomers } from '../api/customers';
import { serviceAreas } from '../api/masters';
import { formatDate } from '../utils/format';
import CustomerCreateDrawer from '../components/customerlist-components/CustomerCreateDrawer';
import { useSnackbar } from '../components/common-components/SnackbarProvider';

function RowActions({ row }) {
  const navigate = useNavigate();
  const snackbar = useSnackbar();
  const [anchor, setAnchor] = useState(null);

  const copyId = () => {
    navigator.clipboard?.writeText(row.customerNumber);
    snackbar.info(`${row.customerNumber} copied to clipboard.`);
    setAnchor(null);
  };

  return (
    <>
      <IconButton size="small" onClick={(e) => setAnchor(e.currentTarget)} aria-label="Row actions">
        <MoreVertIcon fontSize="small" />
      </IconButton>
      <Menu anchorEl={anchor} open={!!anchor} onClose={() => setAnchor(null)}>
        <MenuItem onClick={() => navigate(`/customers/${row.customerNumber}`)}>View Customer</MenuItem>
        <MenuItem onClick={() => navigate(`/customers/${row.customerNumber}?tab=addresses&action=add`)}>Add Address</MenuItem>
        <MenuItem onClick={() => navigate(`/bookings/new?customer=${row.customerNumber}`)}>Create Booking</MenuItem>
        <MenuItem onClick={copyId}>Copy Customer ID</MenuItem>
      </Menu>
    </>
  );
}

export default function CustomerListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [drawerOpen, setDrawerOpen] = useState(false);

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['customers', search, status],
    queryFn: () => listCustomers({ search, status }),
  });

  const columns = useMemo(
    () => [
      {
        field: 'customerNumber',
        headerName: 'Customer ID',
        width: 150,
        renderCell: (params) => <EntityLink type="Customer" id={params.value} />,
      },
      { field: 'name', headerName: 'Customer Name', flex: 1, minWidth: 160 },
      { field: 'mobile', headerName: 'Mobile', width: 130 },
      {
        field: 'defaultAddress',
        headerName: 'Default Area',
        width: 140,
        valueGetter: (v, row) => serviceAreas.find((a) => a.id === row.defaultAddress?.area)?.name || '—',
      },
      { field: 'addressCount', headerName: 'Addresses', width: 100, type: 'number' },
      { field: 'activeSubscriptionCount', headerName: 'Active Subs', width: 110, type: 'number' },
      {
        field: 'nextVisit',
        headerName: 'Next Visit',
        width: 130,
        valueGetter: (v, row) => (row.nextVisit ? formatDate(row.nextVisit.date) : '—'),
      },
      {
        field: 'lifetimeCollected',
        headerName: 'Lifetime Collected',
        width: 160,
        renderCell: (params) => <Money value={params.value} />,
      },
      {
        field: 'status',
        headerName: 'Status',
        width: 110,
        renderCell: (params) => <StatusChip status={params.value} />,
      },
      {
        field: 'createdOn',
        headerName: 'Created On',
        width: 130,
        valueGetter: (v, row) => formatDate(row.createdOn),
      },
      {
        field: 'actions',
        headerName: '',
        width: 60,
        sortable: false,
        filterable: false,
        disableColumnMenu: true,
        renderCell: (params) => <RowActions row={params.row} />,
      },
    ],
    []
  );

  return (
    <>
      <PageHeader
        title="Customers"
        subtitle="Every permanent customer profile and their service addresses."
        actions={
          <Button variant="contained" startIcon={<AddIcon />} onClick={() => setDrawerOpen(true)}>
            Add Customer
          </Button>
        }
      />

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
          <TextField
            size="small"
            placeholder="Search Customer ID, name, or mobile"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ flex: 1, minWidth: 220 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
            }}
          />
          <TextField select size="small" label="Status" value={status} onChange={(e) => setStatus(e.target.value)} sx={{ width: 160 }}>
            <MenuItem value="All">All Statuses</MenuItem>
            <MenuItem value="Active">Active</MenuItem>
            <MenuItem value="Inactive">Inactive</MenuItem>
          </TextField>
        </Stack>
      </Paper>

      <Paper variant="outlined" sx={{ height: 560 }}>
        {isError ? (
          <ErrorState message={error.message} onRetry={refetch} />
        ) : !isLoading && (data?.length ?? 0) === 0 ? (
          <EmptyState
            title="No customers yet"
            description="Register your first customer and their service address to get started."
            actionLabel="Add Customer"
            onAction={() => setDrawerOpen(true)}
          />
        ) : (
          <DataGrid
            rows={data || []}
            columns={columns}
            loading={isLoading}
            disableRowSelectionOnClick
            onRowClick={(params) => navigate(`/customers/${params.row.customerNumber}`)}
            sx={{ border: 'none', '& .MuiDataGrid-row': { cursor: 'pointer' } }}
            initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
            pageSizeOptions={[10, 25, 50]}
          />
        )}
      </Paper>

      <CustomerCreateDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onCreated={(customerNumber) => {
          setDrawerOpen(false);
          navigate(`/customers/${customerNumber}`);
        }}
      />
    </>
  );
}
