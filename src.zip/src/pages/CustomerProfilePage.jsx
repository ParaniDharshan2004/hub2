import { useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import IconButton from '@mui/material/IconButton';
import Avatar from '@mui/material/Avatar';
import Grid from '@mui/material/Grid';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import AddLocationAltOutlinedIcon from '@mui/icons-material/AddLocationAltOutlined';
import EventNoteOutlinedIcon from '@mui/icons-material/EventNoteOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';

import Breadcrumbs from '@mui/material/Breadcrumbs';
import { Link as RouterLink } from 'react-router-dom';
import PageHeader from '../components/common-components/PageHeader';
import StatusChip from '../components/common-components/StatusChip';
import { LoadingSkeleton, ErrorState, EmptyState } from '../components/common-components/PageStates';
import { getCustomer360 } from '../api/customers';
import { serviceAreas } from '../api/masters';
import { formatDate, initials } from '../utils/format';

import OverviewTab from '../components/customerprofile-components/OverviewTab';
import AddressesTab from '../components/customerprofile-components/AddressesTab';
import BookingsTab from '../components/customerprofile-components/BookingsTab';
import SubscriptionsTab from '../components/customerprofile-components/SubscriptionsTab';
import AddAddressDialog from '../components/customerprofile-components/AddAddressDialog';

const TABS = ['overview', 'addresses', 'bookings', 'subscriptions'];

export default function CustomerProfilePage() {
  const { customerNumber } = useParams();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [addAddressOpen, setAddAddressOpen] = useState(
    searchParams.get('action') === 'add' && searchParams.get('tab') === 'addresses'
  );

  const tabParam = searchParams.get('tab');
  const activeTab = TABS.includes(tabParam) ? tabParam : 'overview';

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['customer360', customerNumber],
    queryFn: () => getCustomer360(customerNumber),
  });

  const handleTabChange = (_, value) => {
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      next.set('tab', value);
      next.delete('action');
      return next;
    });
  };

  const goCreateBooking = (address) => {
    navigate(`/bookings/new?customer=${customerNumber}${address ? `&address=${address.addressNumber}` : ''}`);
  };

  if (isLoading) {
    return (
      <>
        <PageHeader title="Loading customer…" breadcrumbs={[{ label: 'Customers', to: '/customers' }, { label: customerNumber }]} />
        <LoadingSkeleton rows={8} />
      </>
    );
  }

  if (isError) {
    return <ErrorState message={error.message} onRetry={refetch} />;
  }

  if (!data) {
    return (
      <Paper variant="outlined">
        <EmptyState title="Customer not found" description={`No customer matches ${customerNumber}.`} />
      </Paper>
    );
  }

  const { customer, addresses, bookings, subscriptions, summary } = data;
  const defaultAddress = addresses.find((a) => a.isDefault) || addresses[0];

  return (
    <>
      <Breadcrumbs sx={{ mb: 2, fontSize: '0.8rem' }}>
        <Box component={RouterLink} to="/customers" sx={{ color: 'text.secondary', textDecoration: 'none', '&:hover': { textDecoration: 'underline' } }}>
          Customers
        </Box>
        <Typography variant="body2" color="text.secondary">
          {customer.customerNumber}
        </Typography>
      </Breadcrumbs>

      <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 }, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item>
            <Avatar sx={{ width: 56, height: 56, bgcolor: 'primary.main', fontSize: '1.1rem' }}>
              {initials(customer.name)}
            </Avatar>
          </Grid>
          <Grid item xs>
            <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap">
              <Typography variant="h2">{customer.name}</Typography>
              <StatusChip status={customer.status} />
            </Stack>
            <Stack direction="row" spacing={2} flexWrap="wrap" sx={{ mt: 0.5 }}>
              <Typography variant="body2" color="text.secondary">
                {customer.customerNumber}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {customer.mobile}
              </Typography>
              {customer.email && (
                <Typography variant="body2" color="text.secondary">
                  {customer.email}
                </Typography>
              )}
              {defaultAddress && (
                <Typography variant="body2" color="text.secondary">
                  {serviceAreas.find((a) => a.id === defaultAddress.area)?.name}
                </Typography>
              )}
              <Typography variant="body2" color="text.secondary">
                {summary.activeSubscriptions} active subscription{summary.activeSubscriptions === 1 ? '' : 's'}
              </Typography>
              {summary.nextVisits[0] && (
                <Typography variant="body2" color="text.secondary">
                  Next visit {formatDate(summary.nextVisits[0].date)}
                </Typography>
              )}
            </Stack>
          </Grid>
          <Grid item>
            <Stack direction="row" spacing={1}>
              <Button size="small" startIcon={<EditOutlinedIcon />}>
                Edit
              </Button>
              <Button size="small" startIcon={<AddLocationAltOutlinedIcon />} onClick={() => setAddAddressOpen(true)}>
                Add Address
              </Button>
              <Button size="small" variant="contained" startIcon={<EventNoteOutlinedIcon />} onClick={() => goCreateBooking()}>
                Create Booking
              </Button>
              <IconButton size="small" onClick={(e) => setMenuAnchor(e.currentTarget)} aria-label="More actions">
                <MoreVertIcon />
              </IconButton>
              <Menu anchorEl={menuAnchor} open={!!menuAnchor} onClose={() => setMenuAnchor(null)}>
                <MenuItem onClick={() => setMenuAnchor(null)}>Download Customer Statement</MenuItem>
                <MenuItem onClick={() => setMenuAnchor(null)}>Deactivate Customer</MenuItem>
              </Menu>
            </Stack>
          </Grid>
        </Grid>
      </Paper>

      <Paper variant="outlined">
        <Tabs value={activeTab} onChange={handleTabChange} variant="scrollable" scrollButtons="auto" sx={{ px: 2 }}>
          <Tab label="Overview" value="overview" />
          <Tab label={`Addresses (${addresses.length})`} value="addresses" />
          <Tab label={`Bookings (${bookings.length})`} value="bookings" />
          <Tab label={`Subscriptions (${subscriptions.length})`} value="subscriptions" />
        </Tabs>
        <Stack sx={{ p: { xs: 2, sm: 3 } }}>
          {activeTab === 'overview' && <OverviewTab data={data} onCreateBooking={goCreateBooking} />}
          {activeTab === 'addresses' && (
            <AddressesTab addresses={addresses} onAddAddress={() => setAddAddressOpen(true)} onCreateBooking={goCreateBooking} />
          )}
          {activeTab === 'bookings' && (
            <BookingsTab bookings={bookings} addresses={addresses} customerNumber={customer.customerNumber} />
          )}
          {activeTab === 'subscriptions' && <SubscriptionsTab subscriptions={subscriptions} addresses={addresses} />}
        </Stack>
      </Paper>

      <AddAddressDialog open={addAddressOpen} onClose={() => setAddAddressOpen(false)} customerNumber={customer.customerNumber} />
    </>
  );
}
