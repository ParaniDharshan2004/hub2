import React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutlined';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutlined';
import { DataGrid } from '@mui/x-data-grid';
import PageHeader from '../components/common-components/PageHeader';
import { PERMISSIONS, ROLE_PERMISSIONS, ROLE_LABELS } from '../api/permission';

const roles = ['SUPER_ADMIN', 'ADMIN', 'USER'];

const columns = [
  { field: 'permission', headerName: 'Permission', flex: 1, minWidth: 300 },
  ...roles.map((role) => ({
    field: role,
    headerName: ROLE_LABELS[role],
    width: 150,
    sortable: false,
    align: 'center',
    headerAlign: 'center',
    renderCell: (params) =>
      params.value ? (
        <CheckCircleOutlineIcon color="success" fontSize="small" aria-label="Allowed" />
      ) : (
        <RemoveCircleOutlineIcon color="disabled" fontSize="small" aria-label="Not allowed" />
      ),
  })),
];

export default function PermissionsPage() {
  const [query, setQuery] = React.useState('');
  const rows = PERMISSIONS
    .filter((permission) => permission.toLowerCase().includes(query.toLowerCase()))
    .map((permission) => ({
      id: permission,
      permission,
      ...Object.fromEntries(roles.map((role) => [role, ROLE_PERMISSIONS[role].has(permission)])),
    }));

  return (
    <>
      <PageHeader
        title="Permissions"
        subtitle="Review access granted to each role across the Bathroom Care operations console."
      />
      <Card>
        <CardContent>
          <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1.5 }}>
            <TextField
              label="Search permissions"
              size="small"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
            <Chip label={`${rows.length} permissions`} />
          </Stack>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
            Green indicates access is granted. The permission definitions are managed in the permissions API.
          </Typography>
          <DataGrid
            autoHeight
            rows={rows}
            columns={columns}
            disableRowSelectionOnClick
            pageSizeOptions={[10, 25, 50]}
            initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
          />
        </CardContent>
      </Card>
    </>
  );
}