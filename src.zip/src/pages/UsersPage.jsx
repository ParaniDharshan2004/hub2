import React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import { DataGrid } from '@mui/x-data-grid';
import PageHeader from '../components/common-components/PageHeader';
import { ROLE_LABELS } from '../api/permission';

const USERS = [
  {
    id: 'USR-001',
    employeeCode: 'EMP-001',
    displayName: 'Demo Admin',
    email: 'admin@bathroomcare.example',
    role: 'SUPER_ADMIN',
    isActive: true,
    lastLoginAt: '2026-09-11 09:15',
  },
  {
    id: 'USR-002',
    employeeCode: 'EMP-002',
    displayName: 'Operations Manager',
    email: 'operations@bathroomcare.example',
    role: 'ADMIN',
    isActive: true,
    lastLoginAt: '2026-09-10 17:40',
  },
  {
    id: 'USR-003',
    employeeCode: 'EMP-003',
    displayName: 'Accounts Executive',
    email: 'accounts@bathroomcare.example',
    role: 'USER',
    isActive: false,
    lastLoginAt: '2026-08-28 11:05',
  },
];

const columns = [
  { field: 'employeeCode', headerName: 'Employee Code', width: 140 },
  { field: 'displayName', headerName: 'Name', flex: 1, minWidth: 180 },
  { field: 'email', headerName: 'Email', flex: 1, minWidth: 230 },
  {
    field: 'roleLabel',
    headerName: 'Role',
    width: 170,
    renderCell: (params) => <Chip size="small" label={ROLE_LABELS[params.value] || params.value} />,
  },
  {
    field: 'isActive',
    headerName: 'Status',
    width: 110,
    renderCell: (params) => (
      <Chip
        size="small"
        label={params.value ? 'Active' : 'Inactive'}
        color={params.value ? 'success' : 'default'}
      />
    ),
  },
  { field: 'lastLoginAt', headerName: 'Last login', width: 180 },
];

export default function UsersPage() {
  const [query, setQuery] = React.useState('');
  const rows = USERS.filter((user) =>
    Object.values(user).some((value) => String(value).toLowerCase().includes(query.toLowerCase()))
  ).map((user) => ({ ...user, roleLabel: ROLE_LABELS[user.role] || user.role }));

  return (
    <>
      <PageHeader
        title="Users"
        subtitle="User lifecycle, role assignment, effective permissions and activity."
      />
      <Card>
        <CardContent>
          <Stack direction="row" gap={1.5} sx={{ mb: 1.5 }} alignItems="center">
            <TextField
              label="Search users"
              size="small"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
            <Chip label={`${rows.length} users`} />
          </Stack>
          <Typography component="div" sx={{ width: '100%' }}>
            <DataGrid
              autoHeight
              rows={rows}
              columns={columns}
              disableRowSelectionOnClick
              pageSizeOptions={[10, 25]}
              initialState={{ pagination: { paginationModel: { pageSize: 10, page: 0 } } }}
            />
          </Typography>
        </CardContent>
      </Card>
    </>
  );
}