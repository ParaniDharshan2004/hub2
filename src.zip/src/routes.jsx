import { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AppShell from './components/common-components/AppShell';
import { InlineSpinner } from './components/common-components/PageStates';
import ComingSoonPage from './components/common-components/ComingSoonPage';

const CustomerListPage = lazy(() => import('./pages/CustomerListPage'));
const CustomerProfilePage = lazy(() => import('./pages/CustomerProfilePage'));
const BookingListPage = lazy(() => import('./pages/BookingListPage'));
const NewBookingPage = lazy(() => import('./pages/NewBookingPage'));
const BookingDetailPage = lazy(() => import('./pages/BookingDetailPage'));
const UsersPage = lazy(() => import('./pages/UsersPage'));
const PermissionsPage = lazy(() => import('./pages/PermissionsPage'));

function Suspended({ children }) {
  return <Suspense fallback={<InlineSpinner />}>{children}</Suspense>;
}

export default function AppRoutes() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<Navigate to="/customers" replace />} />
        <Route path="/dashboard" element={<ComingSoonPage title="Dashboard" note="KPIs, today's schedule, and collections land right after Visits and Payments are built." />} />

        <Route
          path="/customers"
          element={
            <Suspended>
              <CustomerListPage />
            </Suspended>
          }
        />
        <Route
          path="/customers/:customerNumber"
          element={
            <Suspended>
              <CustomerProfilePage />
            </Suspended>
          }
        />

        <Route
          path="/bookings"
          element={
            <Suspended>
              <BookingListPage />
            </Suspended>
          }
        />
        <Route
          path="/bookings/new"
          element={
            <Suspended>
              <NewBookingPage />
            </Suspended>
          }
        />
        <Route
          path="/bookings/:bookingNumber"
          element={
            <Suspended>
              <BookingDetailPage />
            </Suspended>
          }
        />

        <Route
          path="/subscriptions"
          element={
            <Suspended>
              <ComingSoonPage title="Subscriptions" />
            </Suspended>
          }
        />
        <Route
          path="/subscriptions/:subscriptionNumber"
          element={
            <Suspended>
              <ComingSoonPage title="Subscription" />
            </Suspended>
          }
        />
        <Route
          path="/subscriptions/:subscriptionNumber/renew"
          element={
            <Suspended>
              <ComingSoonPage title="Renew Subscription" />
            </Suspended>
          }
        />

        <Route path="/visits/*" element={<ComingSoonPage title="Visits" />} />
        <Route path="/payments" element={<ComingSoonPage title="Payments" />} />
        <Route path="/invoices" element={<ComingSoonPage title="Invoices" />} />
        <Route path="/reports" element={<ComingSoonPage title="Reports" />} />
        <Route path="/masters/:masterType" element={<ComingSoonPage title="Masters" />} />
        <Route
          path="/admin/users"
          element={
            <Suspended>
              <UsersPage />
            </Suspended>
          }
        />
        <Route
          path="/admin/permissions"
          element={
            <Suspended>
              <PermissionsPage />
            </Suspended>
          }
        />
        <Route path="/admin/*" element={<ComingSoonPage title="Administration" />} />
        <Route path="/settings" element={<ComingSoonPage title="Settings" />} />
        <Route path="/download-center" element={<ComingSoonPage title="Download Center" />} />

        <Route path="*" element={<Navigate to="/customers" replace />} />
      </Route>
    </Routes>
  );
}
